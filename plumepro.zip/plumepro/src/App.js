import { useState } from "react";
import Home from "./pages/Home";
import Services from "./pages/Services";
import Tarifs from "./pages/Tarifs";
import FAQ from "./pages/FAQ";
import Contact from "./pages/Contact";

export default function App() {
  const [page, setPage] = useState("home");

  const navigate = (p) => {
    setPage(p);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const props = { navigate };

  return (
    <>
      {page === "home"     && <Home     {...props} />}
      {page === "services" && <Services {...props} />}
      {page === "tarifs"   && <Tarifs   {...props} />}
      {page === "faq"      && <FAQ      {...props} />}
      {page === "contact"  && <Contact  {...props} />}
    </>
  );
}
