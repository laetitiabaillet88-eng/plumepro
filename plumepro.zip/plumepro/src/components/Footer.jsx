const footerStyles = `
  .footer { background: var(--encre); color: rgba(250,246,241,0.6); padding: 3rem 4rem; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1.5rem; }
  .footer-logo { font-family: 'Playfair Display', serif; font-size: 1.3rem; font-weight: 700; color: var(--creme); background: none; border: none; cursor: pointer; padding: 0; }
  .footer-logo span { color: #e8b4bf; font-style: italic; }
  .footer-links { display: flex; gap: 2rem; list-style: none; font-family: 'Jost', sans-serif; font-size: 0.78rem; letter-spacing: 0.1em; text-transform: uppercase; flex-wrap: wrap; }
  .footer-links button { color: rgba(250,246,241,0.5); background: none; border: none; cursor: pointer; font-family: 'Jost', sans-serif; font-size: 0.78rem; letter-spacing: 0.1em; text-transform: uppercase; transition: color 0.2s; padding: 0; }
  .footer-links button:hover { color: #e8b4bf; }
  .footer-copy { font-family: 'Jost', sans-serif; font-size: 0.75rem; color: rgba(250,246,241,0.35); }

  @media (max-width: 900px) {
    .footer { padding: 2.5rem 1.8rem; flex-direction: column; text-align: center; }
    .footer-links { justify-content: center; }
  }
`;

const links = [
  { label: "Accueil", page: "home" },
  { label: "Services", page: "services" },
  { label: "Tarifs", page: "tarifs" },
  { label: "FAQ", page: "faq" },
  { label: "Contact", page: "contact" },
  { label: "Mentions légales", page: "mentions" },
];

export default function Footer({ navigate }) {
  return (
    <>
      <style>{footerStyles}</style>
      <footer className="footer">
        <button className="footer-logo" onClick={() => navigate("home")}>Plume<span>Pro</span></button>
        <ul className="footer-links">
          {links.map(l => (
            <li key={l.page}><button onClick={() => navigate(l.page)}>{l.label}</button></li>
          ))}
        </ul>
        <span className="footer-copy">© 2026 PlumePro · Tous droits réservés</span>
      </footer>
    </>
  );
}
