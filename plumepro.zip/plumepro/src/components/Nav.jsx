import { useState, useEffect } from "react";

const navStyles = `
  .nav { position: fixed; top: 0; left: 0; right: 0; z-index: 100; display: flex; align-items: center; justify-content: space-between; padding: 1.2rem 4rem; background: rgba(250,246,241,0.93); backdrop-filter: blur(14px); border-bottom: 1px solid rgba(212,137,154,0.2); transition: box-shadow 0.3s; }
  .nav.scrolled { box-shadow: 0 4px 24px rgba(42,31,26,0.07); }
  .nav-logo { font-family: 'Playfair Display', serif; font-size: 1.5rem; font-weight: 700; color: var(--encre); cursor: pointer; letter-spacing: 0.02em; background: none; border: none; padding: 0; }
  .nav-logo span { color: var(--rose); font-style: italic; }
  .nav-links { display: flex; gap: 2.5rem; list-style: none; font-family: 'Jost', sans-serif; font-size: 0.82rem; letter-spacing: 0.12em; text-transform: uppercase; }
  .nav-links button { background: none; border: none; cursor: pointer; color: var(--encre-soft); font-family: 'Jost', sans-serif; font-size: 0.82rem; letter-spacing: 0.12em; text-transform: uppercase; transition: color 0.2s; padding: 0; }
  .nav-links button:hover, .nav-links button.active { color: var(--rose); }
  .nav-cta { font-family: 'Jost', sans-serif; font-size: 0.82rem; letter-spacing: 0.1em; text-transform: uppercase; background: var(--rose); color: white; border: none; padding: 0.65rem 1.6rem; border-radius: 2px; cursor: pointer; transition: background 0.2s, transform 0.15s; }
  .nav-cta:hover { background: var(--rose-deep); transform: translateY(-1px); }
  .nav-burger { display: none; background: none; border: none; cursor: pointer; font-size: 1.4rem; color: var(--encre); }
  .nav-mobile { display: none; position: fixed; top: 65px; left: 0; right: 0; background: rgba(250,246,241,0.98); backdrop-filter: blur(14px); border-bottom: 1px solid rgba(212,137,154,0.2); padding: 1.5rem 2rem; flex-direction: column; gap: 1rem; z-index: 99; }
  .nav-mobile.open { display: flex; }
  .nav-mobile button { background: none; border: none; cursor: pointer; font-family: 'Jost', sans-serif; font-size: 0.9rem; letter-spacing: 0.12em; text-transform: uppercase; color: var(--encre-soft); text-align: left; padding: 0.5rem 0; border-bottom: 1px solid var(--creme-dark); transition: color 0.2s; }
  .nav-mobile button:last-child { border-bottom: none; }
  .nav-mobile button:hover { color: var(--rose); }

  @media (max-width: 900px) {
    .nav { padding: 1rem 1.8rem; }
    .nav-links { display: none; }
    .nav-burger { display: block; }
  }
`;

const links = [
  { label: "Accueil", page: "home" },
  { label: "Services", page: "services" },
  { label: "Tarifs", page: "tarifs" },
  { label: "FAQ", page: "faq" },
  { label: "Contact", page: "contact" },
];

export default function Nav({ current, navigate }) {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const go = (page) => { navigate(page); setMenuOpen(false); };

  return (
    <>
      <style>{navStyles}</style>
      <nav className={`nav${scrolled ? " scrolled" : ""}`}>
        <button className="nav-logo" onClick={() => go("home")}>Plume<span>Pro</span></button>
        <ul className="nav-links">
          {links.map(l => (
            <li key={l.page}>
              <button className={current === l.page ? "active" : ""} onClick={() => go(l.page)}>{l.label}</button>
            </li>
          ))}
        </ul>
        <button className="nav-cta" onClick={() => go("home")}>Essai gratuit</button>
        <button className="nav-burger" onClick={() => setMenuOpen(o => !o)}>{menuOpen ? "✕" : "☰"}</button>
      </nav>
      <div className={`nav-mobile${menuOpen ? " open" : ""}`}>
        {links.map(l => (
          <button key={l.page} onClick={() => go(l.page)}>{l.label}</button>
        ))}
        <button onClick={() => go("home")} style={{color:"var(--rose)", fontWeight:"500"}}>✦ Essai gratuit</button>
      </div>
    </>
  );
}
