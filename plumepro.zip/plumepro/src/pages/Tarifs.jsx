import Nav from '../components/Nav';
import Footer from '../components/Footer';

import { useState } from "react";

const styles = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400;1,600&family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;1,300;1,400&family=Jost:wght@300;400;500&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --creme: #faf6f1; --creme-dark: #f0e9e0;
    --rose: #d4899a; --rose-light: #e8b4bf; --rose-pale: #f5dde3; --rose-deep: #b8637a;
    --or: #c9a84c; --or-light: #e2c47a;
    --encre: #2a1f1a; --encre-soft: #4a3830; --gris: #8a7e78; --blanc: #fdfaf6;
  }
  html { scroll-behavior: smooth; }
  body { font-family: 'Cormorant Garamond', Georgia, serif; background: var(--creme); color: var(--encre); overflow-x: hidden; }

  /* NAV */
  .nav { position: fixed; top: 0; left: 0; right: 0; z-index: 100; display: flex; align-items: center; justify-content: space-between; padding: 1.2rem 4rem; background: rgba(250,246,241,0.93); backdrop-filter: blur(14px); border-bottom: 1px solid rgba(212,137,154,0.2); }
  .nav-logo { font-family: 'Playfair Display', serif; font-size: 1.5rem; font-weight: 700; color: var(--encre); cursor: pointer; }
  .nav-logo span { color: var(--rose); font-style: italic; }
  .nav-links { display: flex; gap: 2.5rem; list-style: none; font-family: 'Jost', sans-serif; font-size: 0.82rem; letter-spacing: 0.12em; text-transform: uppercase; }
  .nav-links a { color: var(--encre-soft); text-decoration: none; transition: color 0.2s; }
  .nav-links a:hover, .nav-links a.active { color: var(--rose); }
  .nav-cta { font-family: 'Jost', sans-serif; font-size: 0.82rem; letter-spacing: 0.1em; text-transform: uppercase; background: var(--rose); color: white; border: none; padding: 0.65rem 1.6rem; border-radius: 2px; cursor: pointer; transition: background 0.2s; }
  .nav-cta:hover { background: var(--rose-deep); }

  /* PAGE HERO */
  .page-hero { padding: 10rem 4rem 5rem; text-align: center; position: relative; overflow: hidden; }
  .page-hero::before { content: ''; position: absolute; width: 500px; height: 500px; border-radius: 50%; background: radial-gradient(circle, rgba(245,221,227,0.45) 0%, transparent 70%); top: -100px; right: -100px; pointer-events: none; }
  .page-hero-tag { font-family: 'Jost', sans-serif; font-size: 0.75rem; letter-spacing: 0.22em; text-transform: uppercase; color: var(--rose); margin-bottom: 1rem; display: flex; align-items: center; justify-content: center; gap: 0.8rem; }
  .page-hero-tag::before, .page-hero-tag::after { content: ''; display: block; width: 30px; height: 1px; background: var(--rose-light); }
  .page-hero h1 { font-family: 'Playfair Display', serif; font-size: clamp(2.4rem, 5vw, 4rem); font-weight: 700; line-height: 1.15; color: var(--encre); margin-bottom: 1.2rem; }
  .page-hero h1 em { font-style: italic; color: var(--rose); }
  .page-hero p { font-size: 1.2rem; font-weight: 300; color: var(--gris); max-width: 580px; margin: 0 auto; line-height: 1.7; }

  /* TOGGLE */
  .toggle-wrap { display: flex; justify-content: center; margin: 3rem auto 0; }
  .pricing-toggle { display: inline-flex; background: var(--creme-dark); border-radius: 4px; padding: 4px; gap: 4px; }
  .toggle-btn { font-family: 'Jost', sans-serif; font-size: 0.82rem; letter-spacing: 0.1em; text-transform: uppercase; border: none; background: transparent; color: var(--gris); padding: 0.7rem 1.8rem; border-radius: 2px; cursor: pointer; transition: all 0.2s; }
  .toggle-btn.active { background: var(--blanc); color: var(--encre); box-shadow: 0 2px 8px rgba(42,31,26,0.08); }

  /* ABONNEMENTS */
  .plans-section { padding: 5rem 4rem; max-width: 1200px; margin: 0 auto; }
  .plans-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1.5rem; }

  .plan-card { background: var(--blanc); border: 1px solid var(--creme-dark); border-radius: 6px; padding: 2.4rem 2rem; position: relative; display: flex; flex-direction: column; transition: transform 0.25s, box-shadow 0.25s; }
  .plan-card:hover { transform: translateY(-5px); box-shadow: 0 16px 40px rgba(212,137,154,0.14); }
  .plan-card.featured { border-color: var(--rose-light); background: linear-gradient(160deg, var(--blanc) 0%, var(--rose-pale) 100%); transform: scale(1.03); }
  .plan-card.featured:hover { transform: scale(1.03) translateY(-5px); }
  .plan-badge { position: absolute; top: -13px; left: 50%; transform: translateX(-50%); background: var(--rose); color: white; font-family: 'Jost', sans-serif; font-size: 0.68rem; letter-spacing: 0.12em; text-transform: uppercase; padding: 0.3rem 1.1rem; border-radius: 20px; white-space: nowrap; }
  .plan-name { font-family: 'Jost', sans-serif; font-size: 0.75rem; letter-spacing: 0.2em; text-transform: uppercase; color: var(--gris); margin-bottom: 1.2rem; }
  .plan-price { font-family: 'Playfair Display', serif; font-size: 2.6rem; font-weight: 700; color: var(--encre); line-height: 1; }
  .plan-price sup { font-size: 1.2rem; vertical-align: super; }
  .plan-period { font-family: 'Cormorant Garamond', serif; font-size: 1rem; font-weight: 300; color: var(--gris); margin-left: 2px; }
  .plan-tagline { font-size: 0.92rem; font-weight: 300; color: var(--gris); margin-top: 0.6rem; font-style: italic; min-height: 2.5rem; }
  .plan-divider { height: 1px; background: var(--creme-dark); margin: 1.6rem 0; }
  .plan-features { list-style: none; display: flex; flex-direction: column; gap: 0.8rem; flex: 1; }
  .plan-features li { display: flex; align-items: flex-start; gap: 0.7rem; font-size: 0.92rem; font-weight: 300; color: var(--encre-soft); line-height: 1.4; }
  .plan-features li .check { color: var(--rose); font-size: 0.75rem; margin-top: 0.15rem; flex-shrink: 0; }
  .plan-features li .dash { color: var(--creme-dark); font-size: 0.75rem; margin-top: 0.15rem; flex-shrink: 0; }
  .plan-features li.disabled { color: var(--gris); opacity: 0.5; }
  .plan-btn { margin-top: 2rem; width: 100%; font-family: 'Jost', sans-serif; font-size: 0.82rem; letter-spacing: 0.1em; text-transform: uppercase; padding: 0.85rem; border-radius: 2px; cursor: pointer; transition: all 0.2s; border: 1px solid rgba(42,31,26,0.2); background: transparent; color: var(--encre-soft); }
  .plan-btn:hover { background: var(--rose); color: white; border-color: var(--rose); }
  .plan-card.featured .plan-btn { background: var(--rose); color: white; border-color: var(--rose); }
  .plan-card.featured .plan-btn:hover { background: var(--rose-deep); border-color: var(--rose-deep); }

  /* CRÉDITS */
  .credits-section { padding: 5rem 4rem; max-width: 1200px; margin: 0 auto; }
  .credits-intro { text-align: center; margin-bottom: 3.5rem; }
  .credits-intro p { font-size: 1.05rem; font-weight: 300; color: var(--gris); line-height: 1.7; max-width: 600px; margin: 0.8rem auto 0; }
  .credits-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1.5rem; margin-bottom: 4rem; }
  .credit-card { background: var(--blanc); border: 1px solid var(--creme-dark); border-radius: 6px; padding: 2rem 1.8rem; text-align: center; position: relative; transition: transform 0.25s, box-shadow 0.25s; }
  .credit-card:hover { transform: translateY(-4px); box-shadow: 0 12px 32px rgba(212,137,154,0.14); }
  .credit-card.featured { border-color: var(--rose-light); background: linear-gradient(135deg, var(--blanc) 0%, var(--rose-pale) 100%); }
  .credit-badge { position: absolute; top: -12px; left: 50%; transform: translateX(-50%); background: var(--rose); color: white; font-family: 'Jost', sans-serif; font-size: 0.68rem; letter-spacing: 0.12em; text-transform: uppercase; padding: 0.3rem 1rem; border-radius: 20px; white-space: nowrap; }
  .credit-amount { font-family: 'Playfair Display', serif; font-size: 2.2rem; font-weight: 700; color: var(--rose); }
  .credit-label { font-family: 'Jost', sans-serif; font-size: 0.72rem; letter-spacing: 0.15em; text-transform: uppercase; color: var(--gris); margin-top: 0.2rem; }
  .credit-price { font-family: 'Playfair Display', serif; font-size: 1.6rem; font-weight: 700; color: var(--encre); margin-top: 1rem; }
  .credit-saving { font-family: 'Jost', sans-serif; font-size: 0.72rem; letter-spacing: 0.08em; text-transform: uppercase; color: var(--rose-deep); background: var(--rose-pale); padding: 0.3rem 0.8rem; border-radius: 20px; display: inline-block; margin-top: 0.4rem; }
  .credit-divider { height: 1px; background: var(--creme-dark); margin: 1.2rem 0; }
  .credit-uses { list-style: none; display: flex; flex-direction: column; gap: 0.5rem; text-align: left; }
  .credit-uses li { font-size: 0.88rem; font-weight: 300; color: var(--encre-soft); display: flex; align-items: center; gap: 0.5rem; }
  .credit-uses li::before { content: '✦'; color: var(--rose-light); font-size: 0.6rem; flex-shrink: 0; }
  .credit-btn { margin-top: 1.6rem; width: 100%; font-family: 'Jost', sans-serif; font-size: 0.8rem; letter-spacing: 0.1em; text-transform: uppercase; padding: 0.8rem; border-radius: 2px; cursor: pointer; transition: all 0.2s; border: 1px solid rgba(42,31,26,0.2); background: transparent; color: var(--encre-soft); }
  .credit-btn:hover { background: var(--rose); color: white; border-color: var(--rose); }
  .credit-card.featured .credit-btn { background: var(--rose); color: white; border-color: var(--rose); }

  /* TARIF À L'UNITÉ */
  .unit-section { background: var(--blanc); border-top: 1px solid var(--creme-dark); border-bottom: 1px solid var(--creme-dark); padding: 4rem; }
  .unit-inner { max-width: 900px; margin: 0 auto; }
  .unit-title { font-family: 'Playfair Display', serif; font-size: 1.5rem; font-weight: 700; color: var(--encre); margin-bottom: 0.5rem; text-align: center; }
  .unit-title em { font-style: italic; color: var(--rose); }
  .unit-sub { font-size: 1rem; font-weight: 300; color: var(--gris); text-align: center; margin-bottom: 2.5rem; }
  .unit-table { width: 100%; border-collapse: collapse; }
  .unit-table th { font-family: 'Jost', sans-serif; font-size: 0.72rem; letter-spacing: 0.15em; text-transform: uppercase; color: var(--gris); padding: 0.8rem 1.2rem; border-bottom: 2px solid var(--creme-dark); text-align: left; }
  .unit-table td { padding: 1.1rem 1.2rem; border-bottom: 1px solid var(--creme-dark); font-size: 0.95rem; font-weight: 300; color: var(--encre-soft); }
  .unit-table tr:last-child td { border-bottom: none; }
  .unit-table tr:hover td { background: var(--creme); }
  .unit-service { font-family: 'Playfair Display', serif; font-weight: 600; color: var(--encre); }
  .unit-credits { font-family: 'Jost', sans-serif; font-size: 0.85rem; color: var(--rose); font-weight: 500; }

  /* COMPARAISON */
  .compare-section { padding: 5rem 4rem; max-width: 1000px; margin: 0 auto; }
  .compare-title { font-family: 'Playfair Display', serif; font-size: 2rem; font-weight: 700; color: var(--encre); text-align: center; margin-bottom: 0.5rem; }
  .compare-title em { font-style: italic; color: var(--rose); }
  .compare-sub { font-size: 1rem; font-weight: 300; color: var(--gris); text-align: center; margin-bottom: 2.5rem; }
  .compare-table { width: 100%; border-collapse: collapse; background: var(--blanc); border-radius: 6px; overflow: hidden; box-shadow: 0 4px 20px rgba(42,31,26,0.06); }
  .compare-table th { font-family: 'Jost', sans-serif; font-size: 0.75rem; letter-spacing: 0.15em; text-transform: uppercase; padding: 1.2rem 1.5rem; background: var(--creme-dark); color: var(--encre-soft); text-align: center; }
  .compare-table th:first-child { text-align: left; }
  .compare-table td { padding: 1rem 1.5rem; border-bottom: 1px solid var(--creme-dark); font-size: 0.92rem; font-weight: 300; color: var(--encre-soft); text-align: center; }
  .compare-table td:first-child { text-align: left; font-family: 'Playfair Display', serif; font-weight: 500; color: var(--encre); }
  .compare-table tr:last-child td { border-bottom: none; }
  .compare-table tr:hover td { background: var(--creme); }
  .compare-yes { color: #4a9e6a; font-size: 1rem; }
  .compare-no { color: var(--creme-dark); font-size: 1rem; }
  .compare-highlight { background: rgba(212,137,154,0.06) !important; }
  .compare-table th.highlight { background: var(--rose-pale); color: var(--rose-deep); }

  /* FAQ */
  .faq-section { background: var(--blanc); border-top: 1px solid var(--creme-dark); padding: 5rem 4rem; }
  .faq-inner { max-width: 780px; margin: 0 auto; }
  .faq-header { text-align: center; margin-bottom: 2.5rem; }
  .section-tag { font-family: 'Jost', sans-serif; font-size: 0.75rem; letter-spacing: 0.22em; text-transform: uppercase; color: var(--rose); margin-bottom: 1rem; display: flex; align-items: center; justify-content: center; gap: 0.8rem; }
  .section-tag::before, .section-tag::after { content: ''; display: block; width: 30px; height: 1px; background: var(--rose-light); }
  .faq-h2 { font-family: 'Playfair Display', serif; font-size: 2rem; font-weight: 700; color: var(--encre); }
  .faq-h2 em { font-style: italic; color: var(--rose); }
  .faq-list { display: flex; flex-direction: column; gap: 0.8rem; }
  .faq-item { border: 1px solid var(--creme-dark); border-radius: 4px; overflow: hidden; }
  .faq-q { width: 100%; display: flex; align-items: center; justify-content: space-between; padding: 1.3rem 1.8rem; background: var(--blanc); border: none; cursor: pointer; font-family: 'Playfair Display', serif; font-size: 1.05rem; font-weight: 600; color: var(--encre); text-align: left; gap: 1rem; transition: background 0.2s; }
  .faq-q:hover { background: var(--creme); }
  .faq-arrow { color: var(--rose); font-size: 0.9rem; transition: transform 0.25s; flex-shrink: 0; }
  .faq-arrow.open { transform: rotate(180deg); }
  .faq-a { padding: 0 1.8rem 1.3rem; font-size: 0.98rem; font-weight: 300; color: var(--gris); line-height: 1.7; }

  /* CTA */
  .cta-band { background: linear-gradient(135deg, var(--rose-pale) 0%, var(--creme) 100%); border-top: 1px solid var(--creme-dark); padding: 5rem 4rem; text-align: center; }
  .cta-band h2 { font-family: 'Playfair Display', serif; font-size: clamp(1.8rem, 3.5vw, 2.6rem); font-weight: 700; color: var(--encre); margin-bottom: 1rem; }
  .cta-band h2 em { font-style: italic; color: var(--rose); }
  .cta-band p { font-size: 1.05rem; font-weight: 300; color: var(--gris); margin-bottom: 2rem; }
  .btn-primary { font-family: 'Jost', sans-serif; font-size: 0.85rem; letter-spacing: 0.1em; text-transform: uppercase; background: var(--rose); color: white; border: none; padding: 1rem 2.4rem; border-radius: 2px; cursor: pointer; transition: background 0.2s, transform 0.15s; box-shadow: 0 4px 20px rgba(212,137,154,0.35); }
  .btn-primary:hover { background: var(--rose-deep); transform: translateY(-2px); }
  .cta-fine { margin-top: 1rem; font-size: 0.85rem; color: var(--gris); font-style: italic; }

  /* FOOTER */
  footer { background: var(--encre); color: rgba(250,246,241,0.6); padding: 3rem 4rem; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1.5rem; }
  .footer-logo { font-family: 'Playfair Display', serif; font-size: 1.3rem; font-weight: 700; color: var(--creme); }
  .footer-logo span { color: var(--rose-light); font-style: italic; }
  .footer-links { display: flex; gap: 2rem; list-style: none; font-family: 'Jost', sans-serif; font-size: 0.78rem; letter-spacing: 0.1em; text-transform: uppercase; }
  .footer-links a { color: rgba(250,246,241,0.5); text-decoration: none; transition: color 0.2s; }
  .footer-links a:hover { color: var(--rose-light); }
  .footer-copy { font-family: 'Jost', sans-serif; font-size: 0.75rem; color: rgba(250,246,241,0.35); }

  @media (max-width: 960px) {
    .nav { padding: 1rem 1.8rem; }
    .nav-links { display: none; }
    .page-hero, .plans-section, .credits-section, .unit-section, .compare-section, .faq-section, .cta-band { padding-left: 1.8rem; padding-right: 1.8rem; }
    .plans-grid, .credits-grid { grid-template-columns: 1fr 1fr; }
    .plan-card.featured { transform: none; }
    footer { padding: 2.5rem 1.8rem; flex-direction: column; text-align: center; }
    .footer-links { flex-wrap: wrap; justify-content: center; }
  }
  @media (max-width: 600px) {
    .plans-grid, .credits-grid { grid-template-columns: 1fr; }
  }
`;

const abonnements = [
  {
    name: "Gratuit", price: "0", period: "", tagline: "Pour découvrir PlumePro sans risque",
    featured: false, btnLabel: "Commencer",
    features: [
      { text: "3 corrections de chapitres", ok: true },
      { text: "Sans carte bancaire", ok: true },
      { text: "Accès à l'interface complète", ok: true },
      { text: "Mise en page KDP", ok: false },
      { text: "Générateur de couverture", ok: false },
      { text: "Support prioritaire", ok: false },
    ]
  },
  {
    name: "Starter", price: "6,90", period: "/mois", tagline: "Pour l'auteur qui écrit régulièrement",
    featured: false, btnLabel: "Choisir Starter",
    features: [
      { text: "Corrections illimitées", ok: true },
      { text: "Jusqu'à 30 chapitres/mois", ok: true },
      { text: "Sans engagement", ok: true },
      { text: "Mise en page KDP", ok: false },
      { text: "Générateur de couverture", ok: false },
      { text: "Support prioritaire", ok: false },
    ]
  },
  {
    name: "Pro", price: "12,90", period: "/mois", tagline: "Pour l'auteur qui veut tout faire ici",
    featured: true, btnLabel: "Choisir Pro",
    features: [
      { text: "Corrections illimitées", ok: true },
      { text: "Mises en page illimitées", ok: true },
      { text: "Jusqu'à 50 chapitres/mois", ok: true },
      { text: "Sans engagement", ok: true },
      { text: "Générateur de couverture", ok: false },
      { text: "Support prioritaire", ok: false },
    ]
  },
  {
    name: "Auteur", price: "24,90", period: "/mois", tagline: "Pour l'auteur prolifique et exigeant",
    featured: false, btnLabel: "Choisir Auteur",
    features: [
      { text: "Tout illimité", ok: true },
      { text: "5 couvertures/mois incluses", ok: true },
      { text: "Jusqu'à 80 chapitres/mois", ok: true },
      { text: "Sans engagement", ok: true },
      { text: "Support prioritaire", ok: true },
      { text: "Accès anticipé aux nouveautés", ok: true },
    ]
  },
];

const creditsData = [
  { amount: "20", price: "18 €", saving: null, uses: ["4 corrections de chapitres", "ou 1 couverture KDP", "Valable sans limite de temps"] },
  { amount: "50", price: "42 €", saving: "−15%", uses: ["10 corrections de chapitres", "ou 1 couverture + extras", "Idéal pour un roman court"], featured: true },
  { amount: "100", price: "79 €", saving: "−20%", uses: ["Correction + mise en page", "ou 3 couvertures KDP", "Idéal pour un roman complet"] },
  { amount: "200", price: "149 €", saving: "−25%", uses: ["Roman complet + couverture", "Plusieurs projets possibles", "Meilleure valeur du marché"] },
];

const faqs = [
  { q: "Les crédits ont-ils une date d'expiration ?", a: "Non, vos crédits sont valables sans limite de temps. Achetez-en quand vous le souhaitez et utilisez-les à votre rythme." },
  { q: "Puis-je changer d'abonnement à tout moment ?", a: "Oui, vous pouvez passer à un plan supérieur ou inférieur à n'importe quel moment. Le changement prend effet à la prochaine période de facturation." },
  { q: "Que se passe-t-il si j'atteins mon quota mensuel ?", a: "Vous recevez une notification quand vous approchez de votre limite. Vous pouvez alors acheter des crédits supplémentaires à la carte, ou passer à un plan supérieur." },
  { q: "Y a-t-il des frais cachés ?", a: "Aucun. Le prix affiché est le prix que vous payez. Stripe prélève une commission sur chaque transaction (environ 1,5% + 0,25€) mais celle-ci est déjà incluse dans nos tarifs." },
  { q: "Puis-je combiner abonnement et crédits ?", a: "Absolument ! Votre abonnement couvre vos besoins courants, et vous pouvez acheter des crédits supplémentaires pour des projets ponctuels comme une couverture ou une mise en page." },
];

export default function Tarifs({ navigate }) {
  const [tab, setTab] = useState("abonnement");
  const [openFaq, setOpenFaq] = useState(null);

  return (
    <>
      <style>{styles}</style>

      {/* NAV */}
      <nav className="nav">
        <div className="nav-logo">Plume<span>Pro</span></div>
        <ul className="nav-links">
          <li><a href="#">Accueil</a></li>
          <li><a href="#">Services</a></li>
          <li><a href="#" className="active">Tarifs</a></li>
          <li><a href="#">FAQ</a></li>
          <li><a href="#">Contact</a></li>
        </ul>
        <button className="nav-cta">Essai gratuit</button>
      </nav>

      {/* HERO */}
      <div className="page-hero">
        <p className="page-hero-tag">Tarifs</p>
        <h1>Simple, transparent,<br /><em>sans surprise</em></h1>
        <p>Choisissez l'abonnement qui vous convient, ou achetez des crédits à la carte. Les deux systèmes sont cumulables.</p>
        <div className="toggle-wrap">
          <div className="pricing-toggle">
            <button className={`toggle-btn${tab === "abonnement" ? " active" : ""}`} onClick={() => setTab("abonnement")}>Abonnement</button>
            <button className={`toggle-btn${tab === "credits" ? " active" : ""}`} onClick={() => setTab("credits")}>Crédits</button>
          </div>
        </div>
      </div>

      {/* ABONNEMENTS */}
      {tab === "abonnement" && (
        <section className="plans-section">
          <div className="plans-grid">
            {abonnements.map(p => (
              <div key={p.name} className={`plan-card${p.featured ? " featured" : ""}`}>
                {p.featured && <div className="plan-badge">Le plus populaire</div>}
                <p className="plan-name">{p.name}</p>
                <div className="plan-price">
                  {p.price === "0" ? "Gratuit" : <>{p.price}<span className="plan-period">{p.period}</span></>}
                </div>
                <p className="plan-tagline">{p.tagline}</p>
                <div className="plan-divider" />
                <ul className="plan-features">
                  {p.features.map(f => (
                    <li key={f.text} className={!f.ok ? "disabled" : ""}>
                      <span className={f.ok ? "check" : "dash"}>{f.ok ? "✦" : "—"}</span>
                      {f.text}
                    </li>
                  ))}
                </ul>
                <button className="plan-btn">{p.btnLabel}</button>
              </div>
            ))}
          </div>
          <p style={{textAlign:"center", marginTop:"2rem", fontSize:"0.9rem", color:"var(--gris)", fontStyle:"italic"}}>
            Préférez payer à l'usage ?{" "}
            <button onClick={() => setTab("credits")} style={{color:"var(--rose)", background:"none", border:"none", cursor:"pointer", fontStyle:"italic", fontSize:"0.9rem"}}>
              Découvrez nos packs de crédits →
            </button>
          </p>
        </section>
      )}

      {/* CRÉDITS */}
      {tab === "credits" && (
        <section className="credits-section">
          <div className="credits-intro">
            <p>Achetez des crédits une fois, utilisez-les quand vous voulez. Sans abonnement, sans engagement.</p>
          </div>
          <div className="credits-grid">
            {creditsData.map(c => (
              <div key={c.amount} className={`credit-card${c.featured ? " featured" : ""}`}>
                {c.featured && <div className="credit-badge">Meilleure valeur</div>}
                <div className="credit-amount">{c.amount}</div>
                <div className="credit-label">crédits</div>
                <div className="credit-price">{c.price}</div>
                {c.saving && <div className="credit-saving">{c.saving}</div>}
                <div className="credit-divider" />
                <ul className="credit-uses">
                  {c.uses.map(u => <li key={u}>{u}</li>)}
                </ul>
                <button className="credit-btn">Acheter</button>
              </div>
            ))}
          </div>

          {/* Tableau à l'unité */}
          <div className="unit-section" style={{borderRadius:"6px", marginBottom:"0"}}>
            <div className="unit-inner">
              <h3 className="unit-title">Tarif des services <em>en crédits</em></h3>
              <p className="unit-sub">1 crédit = 1 € · Utilisez vos crédits sur n'importe quel service</p>
              <table className="unit-table">
                <thead>
                  <tr>
                    <th>Service</th>
                    <th>Crédits</th>
                    <th>Équivalent €</th>
                    <th>Marché traditionnel</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    ["Correction d'un chapitre", "5 crédits", "5 €", "~50–150 €"],
                    ["Correction roman entier (abonnement)", "inclus", "inclus", "900–4 500 €"],
                    ["Mise en page KDP complète", "49 crédits", "49 €", "80–500 €"],
                    ["Couverture KDP (1 design)", "29 crédits", "29 €", "200–700 €"],
                    ["Pack Roman Complet (correction + mise en page + couverture)", "99 crédits", "99 €", "1 200–5 700 €"],
                  ].map(([s,c,e,m]) => (
                    <tr key={s}>
                      <td><span className="unit-service">{s}</span></td>
                      <td><span className="unit-credits">{c}</span></td>
                      <td>{e}</td>
                      <td style={{color:"var(--gris)", fontStyle:"italic"}}>{m}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <p style={{textAlign:"center", marginTop:"2rem", fontSize:"0.9rem", color:"var(--gris)", fontStyle:"italic"}}>
            Vous écrivez régulièrement ?{" "}
            <button onClick={() => setTab("abonnement")} style={{color:"var(--rose)", background:"none", border:"none", cursor:"pointer", fontStyle:"italic", fontSize:"0.9rem"}}>
              Un abonnement vous coûtera moins cher →
            </button>
          </p>
        </section>
      )}

      {/* TABLEAU COMPARATIF */}
      <section className="compare-section">
        <h2 className="compare-title">Comparer les <em>abonnements</em></h2>
        <p className="compare-sub">Tout en un coup d'œil pour choisir le bon plan</p>
        <table className="compare-table">
          <thead>
            <tr>
              <th>Fonctionnalité</th>
              <th>Gratuit</th>
              <th>Starter</th>
              <th className="highlight">Pro</th>
              <th>Auteur</th>
            </tr>
          </thead>
          <tbody>
            {[
              ["Corrections de chapitres", "3 offertes", "30/mois", "50/mois", "80/mois"],
              ["Mise en page KDP", "✗", "✗", "✓", "✓"],
              ["Générateur de couverture", "✗", "✗", "✗", "5/mois"],
              ["Achat de crédits supplémentaires", "✓", "✓", "✓", "✓"],
              ["Support prioritaire", "✗", "✗", "✗", "✓"],
              ["Accès anticipé nouveautés", "✗", "✗", "✗", "✓"],
              ["Sans engagement", "—", "✓", "✓", "✓"],
            ].map(([feat, ...vals]) => (
              <tr key={feat}>
                <td>{feat}</td>
                {vals.map((v, i) => (
                  <td key={i} className={i === 1 ? "compare-highlight" : ""}>
                    {v === "✓" ? <span className="compare-yes">✓</span> : v === "✗" ? <span className="compare-no">✗</span> : v}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      {/* FAQ */}
      <div className="faq-section">
        <div className="faq-inner">
          <div className="faq-header">
            <p className="section-tag">Questions fréquentes</p>
            <h2 className="faq-h2">Tout savoir sur <em>nos tarifs</em></h2>
          </div>
          <div className="faq-list">
            {faqs.map((f, i) => (
              <div key={i} className="faq-item">
                <button className="faq-q" onClick={() => setOpenFaq(openFaq === i ? null : i)}>
                  {f.q}
                  <span className={`faq-arrow${openFaq === i ? " open" : ""}`}>▼</span>
                </button>
                {openFaq === i && <div className="faq-a">{f.a}</div>}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="cta-band">
        <h2>Commencez <em>gratuitement</em><br />dès aujourd'hui</h2>
        <p>3 corrections offertes, sans carte bancaire. Publiez votre roman avec confiance.</p>
        <button className="btn-primary">Essayer gratuitement</button>
        <p className="cta-fine">✦ Sans carte bancaire · Sans engagement · Résiliable à tout moment</p>
      </div>

      {/* FOOTER */}
      <footer>
        <div className="footer-logo">Plume<span>Pro</span></div>
        <ul className="footer-links">
          {["Accueil","Services","Tarifs","FAQ","Contact","Mentions légales"].map(l => <li key={l}><a href="#">{l}</a></li>)}
        </ul>
        <span className="footer-copy">© 2026 PlumePro · Tous droits réservés</span>
      </footer>
    </>
  );
}
