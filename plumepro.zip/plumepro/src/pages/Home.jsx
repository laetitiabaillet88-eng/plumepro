import { useState } from "react";
import Nav from "../components/Nav";
import Footer from "../components/Footer";

// All styles inline to keep self-contained
const s = `
  .hero { position: relative; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 8rem 4rem 4rem; overflow: hidden; }
  .hero-circle { position: absolute; border-radius: 50%; pointer-events: none; }
  .hero-circle.c1 { width: 600px; height: 600px; background: radial-gradient(circle, rgba(245,221,227,0.55) 0%, transparent 70%); top: -100px; right: -150px; }
  .hero-circle.c2 { width: 400px; height: 400px; background: radial-gradient(circle, rgba(201,168,76,0.12) 0%, transparent 70%); bottom: 50px; left: -80px; }
  .hero-inner { position: relative; z-index: 1; max-width: 900px; text-align: center; }
  .hero-eyebrow { font-family: 'Jost', sans-serif; font-size: 0.78rem; letter-spacing: 0.22em; text-transform: uppercase; color: var(--rose); margin-bottom: 1.8rem; display: flex; align-items: center; justify-content: center; gap: 1rem; opacity:0; animation: fadeUp 0.7s ease forwards; }
  .hero-eyebrow::before, .hero-eyebrow::after { content:''; display:block; width:40px; height:1px; background: var(--rose-light); }
  .hero-title { font-family: 'Playfair Display', serif; font-size: clamp(2.8rem,6vw,5rem); font-weight:700; line-height:1.12; color: var(--encre); margin-bottom:1.5rem; opacity:0; animation: fadeUp 0.7s 0.12s ease forwards; }
  .hero-title em { font-style:italic; color: var(--rose); }
  .hero-subtitle { font-size: clamp(1.1rem,2vw,1.35rem); font-weight:300; color: var(--encre-soft); line-height:1.7; max-width:620px; margin:0 auto 2.8rem; opacity:0; animation: fadeUp 0.7s 0.22s ease forwards; }
  .hero-buttons { display:flex; gap:1.2rem; justify-content:center; flex-wrap:wrap; opacity:0; animation: fadeUp 0.7s 0.32s ease forwards; }
  .hero-note { margin-top:1.6rem; font-size:0.88rem; color: var(--gris); font-style:italic; opacity:0; animation: fadeUp 0.7s 0.42s ease forwards; }
  .stats { background: var(--blanc); border-top:1px solid var(--creme-dark); border-bottom:1px solid var(--creme-dark); padding:3rem 4rem; display:flex; justify-content:center; gap:5rem; flex-wrap:wrap; }
  .stat-item { text-align:center; }
  .stat-number { font-family:'Playfair Display',serif; font-size:2.4rem; font-weight:700; color:var(--rose); display:block; }
  .stat-label { font-family:'Jost',sans-serif; font-size:0.78rem; letter-spacing:0.12em; text-transform:uppercase; color:var(--gris); margin-top:0.3rem; }
  .services-wrap { padding:7rem 4rem; max-width:1200px; margin:0 auto; }
  .services-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(300px,1fr)); gap:2rem; }
  .svc-card { background:var(--blanc); border:1px solid var(--creme-dark); border-radius:4px; padding:2.8rem 2.4rem; position:relative; overflow:hidden; transition:transform 0.25s,box-shadow 0.25s,border-color 0.25s; cursor:pointer; }
  .svc-card::before { content:''; position:absolute; top:0; left:0; right:0; height:3px; background:linear-gradient(90deg,var(--rose-light),var(--or-light)); opacity:0; transition:opacity 0.25s; }
  .svc-card:hover { transform:translateY(-5px); box-shadow:0 16px 40px rgba(212,137,154,0.15); border-color:var(--rose-light); }
  .svc-card:hover::before { opacity:1; }
  .svc-icon { width:54px; height:54px; background:var(--rose-pale); border-radius:50%; display:flex; align-items:center; justify-content:center; margin-bottom:1.6rem; font-size:1.4rem; }
  .svc-name { font-family:'Playfair Display',serif; font-size:1.3rem; font-weight:600; color:var(--encre); margin-bottom:0.8rem; }
  .svc-desc { font-size:1rem; font-weight:300; color:var(--gris); line-height:1.65; }
  .svc-price { margin-top:1.6rem; font-family:'Jost',sans-serif; font-size:0.8rem; letter-spacing:0.08em; color:var(--rose); text-transform:uppercase; }
  .svc-link { display:inline-flex; align-items:center; gap:0.5rem; margin-top:1.2rem; font-family:'Jost',sans-serif; font-size:0.8rem; letter-spacing:0.1em; text-transform:uppercase; color:var(--encre-soft); background:none; border:none; border-bottom:1px solid transparent; cursor:pointer; padding:0; transition:color 0.2s,border-color 0.2s; }
  .svc-link:hover { color:var(--rose); border-bottom-color:var(--rose); }
  .why { background:var(--blanc); border-top:1px solid var(--creme-dark); border-bottom:1px solid var(--creme-dark); padding:7rem 4rem; }
  .why-inner { max-width:1100px; margin:0 auto; display:grid; grid-template-columns:1fr 1fr; gap:5rem; align-items:center; }
  .why-list { list-style:none; display:flex; flex-direction:column; gap:1.5rem; margin-top:2rem; }
  .why-item { display:flex; gap:1.2rem; align-items:flex-start; }
  .why-icon { flex-shrink:0; width:36px; height:36px; background:var(--rose-pale); border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:0.95rem; }
  .why-item-title { font-family:'Playfair Display',serif; font-size:1.05rem; font-weight:600; color:var(--encre); margin-bottom:0.3rem; }
  .why-item-desc { font-size:0.95rem; font-weight:300; color:var(--gris); line-height:1.6; }
  .why-visual { position:relative; display:flex; align-items:center; justify-content:center; }
  .why-stack { position:relative; width:320px; height:380px; }
  .wcard { position:absolute; background:var(--blanc); border:1px solid var(--creme-dark); border-radius:6px; padding:1.8rem; box-shadow:0 8px 30px rgba(42,31,26,0.08); }
  .wcard.back { width:260px; top:20px; right:0; transform:rotate(4deg); background:var(--rose-pale); opacity:0.7; }
  .wcard.front { width:280px; top:40px; left:0; transform:rotate(-2deg); }
  .wcard-label { font-family:'Jost',sans-serif; font-size:0.7rem; letter-spacing:0.15em; text-transform:uppercase; color:var(--rose); margin-bottom:0.8rem; }
  .wcard-title { font-family:'Playfair Display',serif; font-size:1.1rem; font-weight:600; color:var(--encre); margin-bottom:0.6rem; }
  .wcard-line { height:1px; background:var(--creme-dark); margin:0.8rem 0; }
  .wcard-text { font-size:0.88rem; font-weight:300; color:var(--gris); line-height:1.6; }
  .wcard-badge { display:inline-flex; align-items:center; gap:0.4rem; margin-top:1rem; background:var(--rose-pale); color:var(--rose-deep); font-family:'Jost',sans-serif; font-size:0.72rem; letter-spacing:0.08em; text-transform:uppercase; padding:0.4rem 0.9rem; border-radius:20px; }
  .ptoggle { display:inline-flex; background:var(--creme-dark); border-radius:4px; padding:4px; margin:2rem auto; gap:4px; }
  .ptoggle-btn { font-family:'Jost',sans-serif; font-size:0.8rem; letter-spacing:0.1em; text-transform:uppercase; border:none; background:transparent; color:var(--gris); padding:0.6rem 1.4rem; border-radius:2px; cursor:pointer; transition:all 0.2s; }
  .ptoggle-btn.active { background:var(--blanc); color:var(--encre); box-shadow:0 2px 8px rgba(42,31,26,0.08); }
  .pgrid { display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:1.5rem; margin-top:2rem; }
  .pcard { background:var(--blanc); border:1px solid var(--creme-dark); border-radius:4px; padding:2.4rem 2rem; text-align:center; transition:transform 0.25s,box-shadow 0.25s; position:relative; }
  .pcard:hover { transform:translateY(-4px); box-shadow:0 12px 32px rgba(212,137,154,0.14); }
  .pcard.feat { border-color:var(--rose-light); background:linear-gradient(135deg,var(--blanc) 0%,var(--rose-pale) 100%); }
  .pbadge { position:absolute; top:-12px; left:50%; transform:translateX(-50%); background:var(--rose); color:white; font-family:'Jost',sans-serif; font-size:0.68rem; letter-spacing:0.12em; text-transform:uppercase; padding:0.3rem 1rem; border-radius:20px; white-space:nowrap; }
  .pplan { font-family:'Jost',sans-serif; font-size:0.75rem; letter-spacing:0.18em; text-transform:uppercase; color:var(--gris); margin-bottom:1rem; }
  .pprice { font-family:'Playfair Display',serif; font-size:2.2rem; font-weight:700; color:var(--encre); line-height:1; }
  .pprice span { font-size:1rem; font-weight:400; color:var(--gris); font-family:'Cormorant Garamond',serif; }
  .pline { height:1px; background:var(--creme-dark); margin:1.4rem 0; }
  .pfeats { list-style:none; display:flex; flex-direction:column; gap:0.7rem; text-align:left; }
  .pfeats li { font-size:0.9rem; font-weight:300; color:var(--encre-soft); display:flex; align-items:flex-start; gap:0.6rem; }
  .pfeats li::before { content:'✦'; color:var(--rose-light); font-size:0.65rem; margin-top:0.22rem; flex-shrink:0; }
  .pbtn { margin-top:1.8rem; width:100%; font-family:'Jost',sans-serif; font-size:0.8rem; letter-spacing:0.1em; text-transform:uppercase; background:transparent; color:var(--encre-soft); border:1px solid rgba(42,31,26,0.2); padding:0.75rem; border-radius:2px; cursor:pointer; transition:all 0.2s; }
  .pbtn:hover,.pcard.feat .pbtn { background:var(--rose); color:white; border-color:var(--rose); }
  .testis { background:linear-gradient(135deg,var(--rose-pale) 0%,var(--creme) 100%); border-top:1px solid var(--creme-dark); padding:7rem 4rem; }
  .testis-inner { max-width:1100px; margin:0 auto; }
  .testis-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(280px,1fr)); gap:2rem; margin-top:3.5rem; }
  .tcard { background:rgba(253,250,246,0.8); border:1px solid rgba(212,137,154,0.2); border-radius:4px; padding:2.2rem; }
  .tquote { font-size:3rem; line-height:1; color:var(--rose-light); font-family:'Playfair Display',serif; margin-bottom:0.5rem; }
  .ttext { font-size:1rem; font-weight:300; color:var(--encre-soft); line-height:1.7; font-style:italic; margin-bottom:1.5rem; }
  .tauthor { display:flex; align-items:center; gap:0.9rem; }
  .tavatar { width:38px; height:38px; border-radius:50%; background:var(--rose-pale); border:2px solid var(--rose-light); display:flex; align-items:center; justify-content:center; font-size:0.9rem; }
  .tname { font-family:'Playfair Display',serif; font-size:0.95rem; font-weight:600; color:var(--encre); }
  .trole { font-family:'Jost',sans-serif; font-size:0.72rem; letter-spacing:0.1em; text-transform:uppercase; color:var(--gris); }
  .cta-wrap { padding:7rem 4rem; text-align:center; max-width:800px; margin:0 auto; }
  @media(max-width:900px){
    .hero,.services-wrap,.why,.testis,.cta-wrap{padding-left:1.8rem;padding-right:1.8rem;}
    .stats{padding:2.5rem 1.8rem;gap:2.5rem;}
    .why-inner{grid-template-columns:1fr;gap:3rem;}
    .why-visual{display:none;}
  }
`;

const abos = [
  {plan:"Gratuit",price:"0 €",period:"",feats:["3 corrections de chapitres","Sans carte bancaire","Pour tester le service"],feat:false},
  {plan:"Starter",price:"6,90 €",period:"/mois",feats:["Corrections illimitées","Jusqu'à 30 chapitres/mois","Sans engagement"],feat:false},
  {plan:"Pro",price:"12,90 €",period:"/mois",feats:["Corrections illimitées","Mises en page illimitées","Jusqu'à 50 chapitres/mois","Sans engagement"],feat:true},
  {plan:"Auteur",price:"24,90 €",period:"/mois",feats:["Tout illimité","5 couvertures/mois incluses","Jusqu'à 80 chapitres/mois","Support prioritaire"],feat:false},
];
const creds = [
  {plan:"Starter",price:"18 €",period:"",feats:["20 crédits","4 corrections de chapitres","Valable sans limite"],feat:false},
  {plan:"Standard",price:"42 €",period:"",feats:["50 crédits","−15% vs à l'unité","Mise en page incluse"],feat:true},
  {plan:"Pro",price:"79 €",period:"",feats:["100 crédits","−20% vs à l'unité","3 couvertures KDP"],feat:false},
  {plan:"Auteur",price:"149 €",period:"",feats:["200 crédits","−25% vs à l'unité","Pack roman complet"],feat:false},
];

export default function Home({ navigate }) {
  const [tab, setTab] = useState("abo");
  const plans = tab === "abo" ? abos : creds;
  return (
    <>
      <style>{s}</style>
      <Nav current="home" navigate={navigate} />

      <section className="hero">
        <div className="hero-circle c1"/><div className="hero-circle c2"/>
        <div className="hero-inner">
          <p className="hero-eyebrow">L'assistant dédié aux auteurs</p>
          <h1 className="hero-title">Votre roman mérite<br/><em>le meilleur</em> des soins</h1>
          <p className="hero-subtitle">Correction, mise en page KDP et création de couverture — tout ce dont vous avez besoin pour publier avec confiance, au prix le plus accessible du marché.</p>
          <div className="hero-buttons">
            <button className="btn-primary">Commencer gratuitement</button>
            <button className="btn-secondary" onClick={()=>navigate("services")}>Découvrir les services</button>
          </div>
          <p className="hero-note">✦ 3 corrections offertes · Sans carte bancaire</p>
        </div>
      </section>

      <div className="stats">
        {[["10×","Moins cher que les pros"],["3","Services en un seul endroit"],["100%","Dédié à l'autoédition"],["KDP","Formats optimisés Amazon"]].map(([n,l])=>(
          <div className="stat-item" key={l}><span className="stat-number">{n}</span><span className="stat-label">{l}</span></div>
        ))}
      </div>

      <section className="services-wrap">
        <div className="section-header">
          <p className="section-tag">Nos services</p>
          <h2 className="section-title">Tout ce qu'il faut pour<br/><em>publier votre roman</em></h2>
          <p className="section-sub">Des outils professionnels, accessibles à tous les auteurs</p>
        </div>
        <div className="services-grid">
          {[
            {icon:"✍️",name:"Correction intelligente",desc:"Orthographe, grammaire, style et fluidité — votre texte corrigé chapitre par chapitre, dans le respect de votre voix d'auteur.",price:"À partir de 5 crédits / chapitre"},
            {icon:"📐",name:"Mise en page KDP",desc:"Votre manuscrit mis en page aux normes Amazon KDP — marges, typographie, en-têtes, numérotation. Prêt à publier en quelques clics.",price:"À partir de 49 crédits / roman"},
            {icon:"🎨",name:"Générateur de couverture",desc:"Choisissez votre genre, votre ambiance, vos couleurs — l'IA génère des propositions que vous personnalisez librement. Export aux dimensions KDP.",price:"À partir de 29 crédits / couverture"},
          ].map(sv=>(
            <div className="svc-card" key={sv.name} onClick={()=>navigate("services")}>
              <div className="svc-icon">{sv.icon}</div>
              <h3 className="svc-name">{sv.name}</h3>
              <p className="svc-desc">{sv.desc}</p>
              <p className="svc-price">{sv.price}</p>
              <button className="svc-link">En savoir plus →</button>
            </div>
          ))}
        </div>
      </section>

      <section className="why">
        <div className="why-inner">
          <div>
            <p className="section-tag" style={{justifyContent:"flex-start"}}>Pourquoi PlumePro</p>
            <h2 className="section-title">La qualité pro,<br/><em>sans le prix pro</em></h2>
            <ul className="why-list">
              {[
                {icon:"💸",title:"10× moins cher que le marché",desc:"Un correcteur humain facture entre 900 € et 4 500 € pour un roman. Chez nous, moins de 200 €."},
                {icon:"⚡",title:"Rapide et disponible 24h/24",desc:"Pas d'attente, pas de délai. Vos chapitres traités en quelques minutes, à toute heure."},
                {icon:"🎯",title:"Conçu pour l'autoédition KDP",desc:"Chaque service est calibré pour les normes Amazon KDP. Pas de surprise au moment de publier."},
                {icon:"✨",title:"Votre style préservé",desc:"Notre IA corrige sans réécrire. Votre voix, votre ton, votre univers — intacts."},
              ].map(w=>(
                <li className="why-item" key={w.title}>
                  <div className="why-icon">{w.icon}</div>
                  <div><p className="why-item-title">{w.title}</p><p className="why-item-desc">{w.desc}</p></div>
                </li>
              ))}
            </ul>
          </div>
          <div className="why-visual">
            <div className="why-stack">
              <div className="wcard back"><div className="wcard-label">Mise en page</div><div className="wcard-title">Le Secret des Abysses</div><div className="wcard-line"/><div className="wcard-text">Format KDP optimisé ✓</div></div>
              <div className="wcard front"><div className="wcard-label">Correction — Chapitre 3</div><div className="wcard-title">Il faisait nuit noire…</div><div className="wcard-line"/><div className="wcard-text">12 corrections apportées. Style préservé, fluidité améliorée.</div><div className="wcard-badge">✦ Prêt à publier</div></div>
            </div>
          </div>
        </div>
      </section>

      <section style={{padding:"7rem 4rem",maxWidth:"1100px",margin:"0 auto",textAlign:"center"}}>
        <div className="section-header">
          <p className="section-tag">Tarifs</p>
          <h2 className="section-title">Simple, transparent,<br/><em>sans surprise</em></h2>
          <p className="section-sub">Abonnement mensuel ou crédits à la carte</p>
        </div>
        <div className="ptoggle">
          <button className={`ptoggle-btn${tab==="abo"?" active":""}`} onClick={()=>setTab("abo")}>Abonnement</button>
          <button className={`ptoggle-btn${tab==="cred"?" active":""}`} onClick={()=>setTab("cred")}>Crédits</button>
        </div>
        <div className="pgrid">
          {plans.map(p=>(
            <div key={p.plan} className={`pcard${p.feat?" feat":""}`}>
              {p.feat&&<div className="pbadge">Le plus populaire</div>}
              <p className="pplan">{p.plan}</p>
              <div className="pprice">{p.price}<span>{p.period}</span></div>
              <div className="pline"/>
              <ul className="pfeats">{p.feats.map(f=><li key={f}>{f}</li>)}</ul>
              <button className="pbtn" onClick={()=>navigate("tarifs")}>{p.plan==="Gratuit"?"Commencer":"Choisir"}</button>
            </div>
          ))}
        </div>
        <p style={{marginTop:"1.5rem",fontSize:"0.9rem",color:"var(--gris)",fontStyle:"italic"}}>
          <button onClick={()=>navigate("tarifs")} style={{color:"var(--rose)",background:"none",border:"none",cursor:"pointer",fontStyle:"italic",fontSize:"0.9rem"}}>Voir tous les détails sur la page tarifs →</button>
        </p>
      </section>

      <section className="testis">
        <div className="testis-inner">
          <div className="section-header">
            <p className="section-tag">Témoignages</p>
            <h2 className="section-title">Ce qu'en disent<br/><em>les auteurs</em></h2>
          </div>
          <div className="testis-grid">
            {[
              {text:"J'ai corrigé mon roman de 90 000 mots en quelques jours. Ma voix est intacte, les fautes ont disparu. C'est bluffant pour ce prix.",name:"Sophie M.",role:"Auteure de romance — KDP",e:"📚"},
              {text:"La mise en page KDP m'a évité des heures de frustration. Mon livre est exactement comme je l'imaginais, directement prêt à publier.",name:"Marc T.",role:"Auteur de thriller — autoédition",e:"✍️"},
              {text:"Le générateur de couverture est magique. En 20 minutes j'avais une couverture professionnelle que j'ai juste retouchée selon mes goûts.",name:"Lucie R.",role:"Auteure fantasy — 3 romans publiés",e:"🎨"},
            ].map(t=>(
              <div className="tcard" key={t.name}>
                <div className="tquote">"</div>
                <p className="ttext">{t.text}</p>
                <div className="tauthor"><div className="tavatar">{t.e}</div><div><p className="tname">{t.name}</p><p className="trole">{t.role}</p></div></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-wrap">
        <p className="section-tag" style={{justifyContent:"center"}}>Prêt à commencer ?</p>
        <h2 className="section-title">Votre prochain roman<br/><em>n'attend que vous</em></h2>
        <p style={{fontSize:"1.1rem",fontWeight:300,color:"var(--gris)",lineHeight:1.7,margin:"1.5rem auto 2.5rem",maxWidth:"560px"}}>Rejoignez des centaines d'auteurs qui publient avec confiance grâce à PlumePro. Commencez gratuitement, sans engagement.</p>
        <button className="btn-primary">Essayer gratuitement</button>
        <p className="cta-fine">✦ 3 corrections offertes · Sans carte bancaire · Sans engagement</p>
      </section>

      <Footer navigate={navigate}/>
    </>
  );
}
