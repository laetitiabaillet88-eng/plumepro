import Nav from '../components/Nav';
import Footer from '../components/Footer';

import { useState } from "react";

const styles = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400;1,600&family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;1,300;1,400&family=Jost:wght@300;400;500&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --creme: #faf6f1; --creme-dark: #f0e9e0;
    --rose: #d4899a; --rose-light: #e8b4bf; --rose-pale: #f5dde3; --rose-deep: #b8637a;
    --or: #c9a84c; --or-light: #e2c47a;
    --encre: #2a1f1a; --encre-soft: #4a3830; --gris: #8a7e78; --blanc: #fdfaf6;
  }
  html { scroll-behavior: smooth; }
  body { font-family: 'Cormorant Garamond', Georgia, serif; background: var(--creme); color: var(--encre); overflow-x: hidden; }

  /* NAV */
  .nav { position: fixed; top: 0; left: 0; right: 0; z-index: 100; display: flex; align-items: center; justify-content: space-between; padding: 1.2rem 4rem; background: rgba(250,246,241,0.93); backdrop-filter: blur(14px); border-bottom: 1px solid rgba(212,137,154,0.2); }
  .nav-logo { font-family: 'Playfair Display', serif; font-size: 1.5rem; font-weight: 700; color: var(--encre); cursor: pointer; }
  .nav-logo span { color: var(--rose); font-style: italic; }
  .nav-links { display: flex; gap: 2.5rem; list-style: none; font-family: 'Jost', sans-serif; font-size: 0.82rem; letter-spacing: 0.12em; text-transform: uppercase; }
  .nav-links a { color: var(--encre-soft); text-decoration: none; transition: color 0.2s; }
  .nav-links a:hover, .nav-links a.active { color: var(--rose); }
  .nav-cta { font-family: 'Jost', sans-serif; font-size: 0.82rem; letter-spacing: 0.1em; text-transform: uppercase; background: var(--rose); color: white; border: none; padding: 0.65rem 1.6rem; border-radius: 2px; cursor: pointer; transition: background 0.2s; }
  .nav-cta:hover { background: var(--rose-deep); }

  /* PAGE HERO */
  .page-hero { padding: 10rem 4rem 5rem; text-align: center; position: relative; overflow: hidden; }
  .page-hero::before { content: ''; position: absolute; width: 500px; height: 500px; border-radius: 50%; background: radial-gradient(circle, rgba(245,221,227,0.45) 0%, transparent 70%); top: -100px; right: -100px; pointer-events: none; }
  .page-hero-tag { font-family: 'Jost', sans-serif; font-size: 0.75rem; letter-spacing: 0.22em; text-transform: uppercase; color: var(--rose); margin-bottom: 1rem; display: flex; align-items: center; justify-content: center; gap: 0.8rem; }
  .page-hero-tag::before, .page-hero-tag::after { content: ''; display: block; width: 30px; height: 1px; background: var(--rose-light); }
  .page-hero h1 { font-family: 'Playfair Display', serif; font-size: clamp(2.4rem, 5vw, 4rem); font-weight: 700; line-height: 1.15; color: var(--encre); margin-bottom: 1.2rem; }
  .page-hero h1 em { font-style: italic; color: var(--rose); }
  .page-hero p { font-size: 1.2rem; font-weight: 300; color: var(--gris); max-width: 560px; margin: 0 auto 2rem; line-height: 1.7; }

  /* SEARCH */
  .search-wrap { display: flex; justify-content: center; margin-top: 0.5rem; }
  .search-box { display: flex; align-items: center; gap: 0.8rem; background: var(--blanc); border: 1px solid var(--creme-dark); border-radius: 4px; padding: 0.8rem 1.4rem; width: 100%; max-width: 480px; box-shadow: 0 4px 16px rgba(42,31,26,0.06); transition: border-color 0.2s, box-shadow 0.2s; }
  .search-box:focus-within { border-color: var(--rose-light); box-shadow: 0 4px 20px rgba(212,137,154,0.15); }
  .search-icon { color: var(--rose-light); font-size: 1rem; flex-shrink: 0; }
  .search-input { border: none; background: transparent; font-family: 'Cormorant Garamond', serif; font-size: 1rem; font-weight: 300; color: var(--encre); width: 100%; outline: none; }
  .search-input::placeholder { color: var(--gris); }

  /* CATEGORIES */
  .faq-main { padding: 4rem 4rem 6rem; max-width: 1100px; margin: 0 auto; display: grid; grid-template-columns: 240px 1fr; gap: 4rem; align-items: start; }
  .faq-sidebar { position: sticky; top: 7rem; }
  .sidebar-title { font-family: 'Jost', sans-serif; font-size: 0.72rem; letter-spacing: 0.2em; text-transform: uppercase; color: var(--gris); margin-bottom: 1rem; }
  .sidebar-list { list-style: none; display: flex; flex-direction: column; gap: 0.3rem; }
  .sidebar-item { display: flex; align-items: center; gap: 0.7rem; padding: 0.7rem 1rem; border-radius: 4px; cursor: pointer; font-family: 'Jost', sans-serif; font-size: 0.82rem; letter-spacing: 0.06em; color: var(--encre-soft); transition: background 0.2s, color 0.2s; border: 1px solid transparent; }
  .sidebar-item:hover { background: var(--rose-pale); color: var(--rose-deep); }
  .sidebar-item.active { background: var(--rose-pale); color: var(--rose-deep); border-color: var(--rose-light); font-weight: 500; }
  .sidebar-item-icon { font-size: 0.9rem; }
  .sidebar-count { margin-left: auto; font-size: 0.72rem; background: var(--creme-dark); color: var(--gris); padding: 0.15rem 0.5rem; border-radius: 20px; }
  .sidebar-item.active .sidebar-count { background: var(--rose-light); color: white; }

  /* FAQ CONTENT */
  .faq-content { display: flex; flex-direction: column; gap: 2.5rem; }
  .faq-category-title { font-family: 'Playfair Display', serif; font-size: 1.5rem; font-weight: 700; color: var(--encre); margin-bottom: 1rem; padding-bottom: 0.8rem; border-bottom: 2px solid var(--creme-dark); display: flex; align-items: center; gap: 0.8rem; }
  .faq-category-title em { font-style: italic; color: var(--rose); }
  .faq-category-icon { font-size: 1.2rem; }
  .faq-list { display: flex; flex-direction: column; gap: 0.7rem; }
  .faq-item { border: 1px solid var(--creme-dark); border-radius: 4px; overflow: hidden; background: var(--blanc); transition: border-color 0.2s; }
  .faq-item:hover { border-color: var(--rose-light); }
  .faq-q { width: 100%; display: flex; align-items: center; justify-content: space-between; padding: 1.3rem 1.8rem; background: none; border: none; cursor: pointer; font-family: 'Playfair Display', serif; font-size: 1.05rem; font-weight: 600; color: var(--encre); text-align: left; gap: 1rem; transition: background 0.2s; }
  .faq-q:hover { background: var(--creme); }
  .faq-arrow { color: var(--rose); font-size: 0.9rem; transition: transform 0.25s; flex-shrink: 0; }
  .faq-arrow.open { transform: rotate(180deg); }
  .faq-a { padding: 0 1.8rem 1.4rem; font-size: 1rem; font-weight: 300; color: var(--gris); line-height: 1.75; }
  .faq-a a { color: var(--rose); text-decoration: none; border-bottom: 1px solid var(--rose-light); }
  .faq-a a:hover { border-bottom-color: var(--rose); }

  /* NO RESULTS */
  .no-results { text-align: center; padding: 3rem; color: var(--gris); }
  .no-results-icon { font-size: 2.5rem; margin-bottom: 1rem; }
  .no-results p { font-size: 1rem; font-weight: 300; line-height: 1.6; }

  /* CTA CONTACT */
  .contact-band { background: var(--blanc); border-top: 1px solid var(--creme-dark); border-bottom: 1px solid var(--creme-dark); padding: 4rem; text-align: center; }
  .contact-band h2 { font-family: 'Playfair Display', serif; font-size: 1.8rem; font-weight: 700; color: var(--encre); margin-bottom: 0.8rem; }
  .contact-band h2 em { font-style: italic; color: var(--rose); }
  .contact-band p { font-size: 1rem; font-weight: 300; color: var(--gris); margin-bottom: 1.8rem; }
  .btn-primary { font-family: 'Jost', sans-serif; font-size: 0.85rem; letter-spacing: 0.1em; text-transform: uppercase; background: var(--rose); color: white; border: none; padding: 1rem 2.4rem; border-radius: 2px; cursor: pointer; transition: background 0.2s, transform 0.15s; box-shadow: 0 4px 20px rgba(212,137,154,0.35); }
  .btn-primary:hover { background: var(--rose-deep); transform: translateY(-2px); }

  /* CTA BAND */
  .cta-band { background: linear-gradient(135deg, var(--rose-pale) 0%, var(--creme) 100%); border-top: 1px solid var(--creme-dark); padding: 5rem 4rem; text-align: center; }
  .cta-band h2 { font-family: 'Playfair Display', serif; font-size: clamp(1.8rem, 3.5vw, 2.6rem); font-weight: 700; color: var(--encre); margin-bottom: 1rem; }
  .cta-band h2 em { font-style: italic; color: var(--rose); }
  .cta-band p { font-size: 1.05rem; font-weight: 300; color: var(--gris); margin-bottom: 2rem; }
  .cta-fine { margin-top: 1rem; font-size: 0.85rem; color: var(--gris); font-style: italic; }

  /* FOOTER */
  footer { background: var(--encre); color: rgba(250,246,241,0.6); padding: 3rem 4rem; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1.5rem; }
  .footer-logo { font-family: 'Playfair Display', serif; font-size: 1.3rem; font-weight: 700; color: var(--creme); }
  .footer-logo span { color: var(--rose-light); font-style: italic; }
  .footer-links { display: flex; gap: 2rem; list-style: none; font-family: 'Jost', sans-serif; font-size: 0.78rem; letter-spacing: 0.1em; text-transform: uppercase; }
  .footer-links a { color: rgba(250,246,241,0.5); text-decoration: none; transition: color 0.2s; }
  .footer-links a:hover { color: var(--rose-light); }
  .footer-copy { font-family: 'Jost', sans-serif; font-size: 0.75rem; color: rgba(250,246,241,0.35); }

  @media (max-width: 960px) {
    .nav { padding: 1rem 1.8rem; }
    .nav-links { display: none; }
    .page-hero, .contact-band, .cta-band { padding-left: 1.8rem; padding-right: 1.8rem; }
    .faq-main { grid-template-columns: 1fr; padding: 2rem 1.8rem 4rem; gap: 2rem; }
    .faq-sidebar { position: static; }
    .sidebar-list { flex-direction: row; flex-wrap: wrap; }
    footer { padding: 2.5rem 1.8rem; flex-direction: column; text-align: center; }
    .footer-links { flex-wrap: wrap; justify-content: center; }
  }
`;

const categories = [
  {
    id: "services", icon: "✍️", label: "Services",
    faqs: [
      { q: "Quelle est la différence entre correction et embellissement ?", a: "La correction traite l'orthographe, la grammaire, la ponctuation et la syntaxe. L'embellissement va plus loin : fluidité, répétitions, tournures maladroites — toujours en respectant votre voix d'auteur." },
      { q: "Mon style sera-t-il vraiment préservé lors de la correction ?", a: "Absolument. Notre IA est configurée pour corriger sans réécrire. Elle respecte vos choix stylistiques, votre niveau de langue, vos tournures caractéristiques. Si vous écrivez en argot, en phrasés courts ou avec des particularités narratives, elles seront conservées." },
      { q: "Quels formats de fichiers acceptez-vous ?", a: "Nous acceptons les fichiers .docx, .doc, .txt et .odt. Pour la mise en page KDP, le fichier final vous est livré en .docx et .pdf prêt à importer." },
      { q: "Combien de temps faut-il pour traiter un chapitre ?", a: "La correction d'un chapitre prend en général moins de 2 minutes. La mise en page d'un roman complet est disponible en moins de 5 minutes." },
      { q: "Puis-je utiliser les couvertures pour une publication commerciale ?", a: "Oui, toutes les couvertures créées via PlumePro vous appartiennent entièrement et peuvent être utilisées librement pour vos publications commerciales sur KDP ou ailleurs." },
      { q: "Puis-je corriger un roman en plusieurs fois ?", a: "Oui, c'est même recommandé ! Vous pouvez envoyer votre roman chapitre par chapitre, à votre rythme. Chaque chapitre est traité indépendamment." },
    ]
  },
  {
    id: "tarifs", icon: "💳", label: "Tarifs & Paiements",
    faqs: [
      { q: "Les crédits ont-ils une date d'expiration ?", a: "Non, vos crédits sont valables sans limite de temps. Achetez-en quand vous le souhaitez et utilisez-les à votre rythme, même des mois plus tard." },
      { q: "Puis-je combiner abonnement et crédits ?", a: "Absolument ! Votre abonnement couvre vos besoins courants, et vous pouvez acheter des crédits supplémentaires pour des projets ponctuels comme une couverture ou une mise en page." },
      { q: "Que se passe-t-il si j'atteins mon quota mensuel ?", a: "Vous recevez une notification quand vous approchez de votre limite. Vous pouvez alors acheter des crédits supplémentaires à la carte, ou passer à un plan supérieur sans pénalité." },
      { q: "Comment fonctionne le paiement ?", a: "Les paiements sont sécurisés par Stripe, le leader mondial du paiement en ligne. Vous pouvez payer par carte bancaire. Vos données bancaires ne sont jamais stockées sur nos serveurs." },
      { q: "Puis-je résilier mon abonnement à tout moment ?", a: "Oui, sans frais ni pénalité. Vous pouvez résilier depuis votre espace personnel à n'importe quel moment. Votre abonnement reste actif jusqu'à la fin de la période en cours." },
      { q: "Y a-t-il une facture pour mes paiements ?", a: "Oui, une facture est automatiquement générée et envoyée par email après chaque paiement. Vous pouvez aussi retrouver l'historique de vos factures dans votre espace personnel." },
    ]
  },
  {
    id: "compte", icon: "👤", label: "Mon compte",
    faqs: [
      { q: "Comment créer mon compte PlumePro ?", a: "Cliquez sur 'Essai gratuit' en haut de la page. Vous pouvez vous inscrire avec votre adresse email ou via Google. L'inscription prend moins de 30 secondes." },
      { q: "J'ai oublié mon mot de passe, que faire ?", a: "Cliquez sur 'Mot de passe oublié' sur la page de connexion. Vous recevrez un email avec un lien de réinitialisation valable 24 heures." },
      { q: "Puis-je changer mon adresse email ?", a: "Oui, depuis les paramètres de votre compte. Un email de confirmation sera envoyé à votre nouvelle adresse avant que le changement soit effectif." },
      { q: "Où puis-je retrouver mes fichiers corrigés ?", a: "Tous vos fichiers traités sont disponibles dans votre espace 'Mes projets' pendant 90 jours. Pensez à les télécharger avant cette échéance." },
    ]
  },
  {
    id: "kdp", icon: "📚", label: "KDP & Publication",
    faqs: [
      { q: "Qu'est-ce que Amazon KDP ?", a: "KDP (Kindle Direct Publishing) est la plateforme d'autoédition d'Amazon. Elle vous permet de publier votre livre en format papier (broché) et numérique (ebook Kindle) sans passer par un éditeur, gratuitement." },
      { q: "Quels sont les formats KDP supportés par PlumePro ?", a: "Nous supportons tous les formats papier KDP standards : 15,24 × 22,86 cm (le plus courant), 12,7 × 20,32 cm (poche), et 21,59 × 27,94 cm (grand format). Pour les ebooks, nous exportons en .epub et .mobi." },
      { q: "Ma mise en page sera-t-elle directement importable sur KDP ?", a: "Oui. Le fichier .pdf livré respecte exactement les spécifications KDP : marges avec fond perdu, résolution 300 dpi, polices incorporées. Il vous suffit de l'importer directement sur votre tableau de bord KDP." },
      { q: "PlumePro peut-il m'aider à publier sur d'autres plateformes ?", a: "Pour l'instant, nos services sont optimisés pour Amazon KDP. Cependant, les fichiers livrés sont compatibles avec d'autres plateformes comme Kobo, Fnac ou Smashwords moyennant quelques ajustements mineurs." },
    ]
  },
  {
    id: "confidentialite", icon: "🔒", label: "Confidentialité",
    faqs: [
      { q: "Mes manuscrits sont-ils en sécurité ?", a: "Oui. Vos fichiers sont chiffrés en transit (TLS) et au repos (AES-256). Ils ne sont jamais partagés avec des tiers ni utilisés pour entraîner des modèles d'IA." },
      { q: "PlumePro conserve-t-il mes textes après traitement ?", a: "Vos fichiers traités sont conservés 90 jours dans votre espace personnel pour que vous puissiez les re-télécharger. Après ce délai, ils sont supprimés définitivement de nos serveurs." },
      { q: "Qui a accès à mes manuscrits ?", a: "Personne. Le traitement est entièrement automatisé. Aucun humain chez PlumePro n'a accès à vos textes. Vous restez le seul et unique propriétaire de votre œuvre." },
      { q: "Comment supprimer mon compte et mes données ?", a: "Depuis les paramètres de votre compte, vous pouvez demander la suppression complète de votre compte et de toutes vos données. La suppression est effective dans un délai de 30 jours." },
    ]
  },
];

export default function FAQ({ navigate }) {
  const [activeCategory, setActiveCategory] = useState("services");
  const [openFaq, setOpenFaq] = useState(null);
  const [search, setSearch] = useState("");

  const allFaqs = categories.flatMap(c => c.faqs.map(f => ({ ...f, category: c.id })));

  const filtered = search.trim().length > 1
    ? allFaqs.filter(f =>
        f.q.toLowerCase().includes(search.toLowerCase()) ||
        f.a.toLowerCase().includes(search.toLowerCase())
      )
    : null;

  const displayCategories = filtered
    ? [{ id: "search", icon: "🔍", label: "Résultats", faqs: filtered }]
    : categories.filter(c => activeCategory === "all" || c.id === activeCategory);

  return (
    <>
      <style>{styles}</style>

      {/* NAV */}
      <nav className="nav">
        <div className="nav-logo">Plume<span>Pro</span></div>
        <ul className="nav-links">
          <li><a href="#">Accueil</a></li>
          <li><a href="#">Services</a></li>
          <li><a href="#">Tarifs</a></li>
          <li><a href="#" className="active">FAQ</a></li>
          <li><a href="#">Contact</a></li>
        </ul>
        <button className="nav-cta">Essai gratuit</button>
      </nav>

      {/* HERO */}
      <div className="page-hero">
        <p className="page-hero-tag">Aide & FAQ</p>
        <h1>Vous avez des <em>questions</em> ?<br />Nous avons les réponses.</h1>
        <p>Retrouvez toutes les réponses à vos questions sur nos services, nos tarifs et la publication KDP.</p>
        <div className="search-wrap">
          <div className="search-box">
            <span className="search-icon">🔍</span>
            <input
              className="search-input"
              type="text"
              placeholder="Rechercher une question…"
              value={search}
              onChange={e => { setSearch(e.target.value); setOpenFaq(null); }}
            />
          </div>
        </div>
      </div>

      {/* MAIN */}
      <div className="faq-main">

        {/* SIDEBAR */}
        <aside className="faq-sidebar">
          <p className="sidebar-title">Catégories</p>
          <ul className="sidebar-list">
            {categories.map(c => (
              <li
                key={c.id}
                className={`sidebar-item${activeCategory === c.id && !search ? " active" : ""}`}
                onClick={() => { setActiveCategory(c.id); setSearch(""); setOpenFaq(null); }}
              >
                <span className="sidebar-item-icon">{c.icon}</span>
                {c.label}
                <span className="sidebar-count">{c.faqs.length}</span>
              </li>
            ))}
          </ul>
        </aside>

        {/* FAQ CONTENT */}
        <div className="faq-content">
          {displayCategories.length === 0 || (filtered && filtered.length === 0) ? (
            <div className="no-results">
              <div className="no-results-icon">🔍</div>
              <p>Aucun résultat pour <em>"{search}"</em>.<br />Essayez d'autres mots-clés ou <a href="#contact" style={{color:"var(--rose)"}}>contactez-nous</a>.</p>
            </div>
          ) : (
            displayCategories.map(cat => (
              <div key={cat.id}>
                <h2 className="faq-category-title">
                  <span className="faq-category-icon">{cat.icon}</span>
                  {cat.label === "Résultats"
                    ? <><em>{filtered.length}</em> résultat{filtered.length > 1 ? "s" : ""} pour "{search}"</>
                    : cat.label
                  }
                </h2>
                <div className="faq-list">
                  {cat.faqs.map((f, i) => {
                    const key = `${cat.id}-${i}`;
                    return (
                      <div key={key} className="faq-item">
                        <button className="faq-q" onClick={() => setOpenFaq(openFaq === key ? null : key)}>
                          {f.q}
                          <span className={`faq-arrow${openFaq === key ? " open" : ""}`}>▼</span>
                        </button>
                        {openFaq === key && <div className="faq-a">{f.a}</div>}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* CONTACT */}
      <div className="contact-band">
        <h2>Vous n'avez pas trouvé<br /><em>votre réponse ?</em></h2>
        <p>Notre équipe est disponible pour répondre à toutes vos questions.</p>
        <button className="btn-primary">Nous contacter</button>
      </div>

      {/* CTA */}
      <div className="cta-band">
        <h2>Prêt à publier<br /><em>votre roman ?</em></h2>
        <p>3 corrections offertes, sans carte bancaire. Commencez dès maintenant.</p>
        <button className="btn-primary">Essayer gratuitement</button>
        <p className="cta-fine">✦ Sans carte bancaire · Sans engagement · Résiliable à tout moment</p>
      </div>

      {/* FOOTER */}
      <footer>
        <div className="footer-logo">Plume<span>Pro</span></div>
        <ul className="footer-links">
          {["Accueil","Services","Tarifs","FAQ","Contact","Mentions légales"].map(l => <li key={l}><a href="#">{l}</a></li>)}
        </ul>
        <span className="footer-copy">© 2026 PlumePro · Tous droits réservés</span>
      </footer>
    </>
  );
}
