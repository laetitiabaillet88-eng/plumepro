import Nav from '../components/Nav';
import Footer from '../components/Footer';

const styles = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400;1,600&family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;1,300;1,400&family=Jost:wght@300;400;500&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --creme: #faf6f1; --creme-dark: #f0e9e0;
    --rose: #d4899a; --rose-light: #e8b4bf; --rose-pale: #f5dde3; --rose-deep: #b8637a;
    --or: #c9a84c; --or-light: #e2c47a;
    --encre: #2a1f1a; --encre-soft: #4a3830; --gris: #8a7e78; --blanc: #fdfaf6;
  }
  html { scroll-behavior: smooth; }
  body { font-family: 'Cormorant Garamond', Georgia, serif; background: var(--creme); color: var(--encre); overflow-x: hidden; }

  /* NAV */
  .nav { position: fixed; top: 0; left: 0; right: 0; z-index: 100; display: flex; align-items: center; justify-content: space-between; padding: 1.2rem 4rem; background: rgba(250,246,241,0.93); backdrop-filter: blur(14px); border-bottom: 1px solid rgba(212,137,154,0.2); }
  .nav-logo { font-family: 'Playfair Display', serif; font-size: 1.5rem; font-weight: 700; color: var(--encre); cursor: pointer; }
  .nav-logo span { color: var(--rose); font-style: italic; }
  .nav-links { display: flex; gap: 2.5rem; list-style: none; font-family: 'Jost', sans-serif; font-size: 0.82rem; letter-spacing: 0.12em; text-transform: uppercase; }
  .nav-links a { color: var(--encre-soft); text-decoration: none; transition: color 0.2s; }
  .nav-links a:hover, .nav-links a.active { color: var(--rose); }
  .nav-cta { font-family: 'Jost', sans-serif; font-size: 0.82rem; letter-spacing: 0.1em; text-transform: uppercase; background: var(--rose); color: white; border: none; padding: 0.65rem 1.6rem; border-radius: 2px; cursor: pointer; transition: background 0.2s; }
  .nav-cta:hover { background: var(--rose-deep); }

  /* PAGE HERO */
  .page-hero { padding: 10rem 4rem 5rem; text-align: center; position: relative; overflow: hidden; }
  .page-hero::before { content: ''; position: absolute; width: 500px; height: 500px; border-radius: 50%; background: radial-gradient(circle, rgba(245,221,227,0.45) 0%, transparent 70%); top: -100px; right: -100px; pointer-events: none; }
  .page-hero-tag { font-family: 'Jost', sans-serif; font-size: 0.75rem; letter-spacing: 0.22em; text-transform: uppercase; color: var(--rose); margin-bottom: 1rem; display: flex; align-items: center; justify-content: center; gap: 0.8rem; }
  .page-hero-tag::before, .page-hero-tag::after { content: ''; display: block; width: 30px; height: 1px; background: var(--rose-light); }
  .page-hero h1 { font-family: 'Playfair Display', serif; font-size: clamp(2.4rem, 5vw, 4rem); font-weight: 700; line-height: 1.15; color: var(--encre); margin-bottom: 1.2rem; }
  .page-hero h1 em { font-style: italic; color: var(--rose); }
  .page-hero p { font-size: 1.2rem; font-weight: 300; color: var(--gris); max-width: 580px; margin: 0 auto; line-height: 1.7; }

  /* BUTTONS */
  .btn-primary { font-family: 'Jost', sans-serif; font-size: 0.85rem; letter-spacing: 0.1em; text-transform: uppercase; background: var(--rose); color: white; border: none; padding: 1rem 2.4rem; border-radius: 2px; cursor: pointer; transition: background 0.2s, transform 0.15s, box-shadow 0.2s; box-shadow: 0 4px 20px rgba(212,137,154,0.35); }
  .btn-primary:hover { background: var(--rose-deep); transform: translateY(-2px); }
  .btn-outline { font-family: 'Jost', sans-serif; font-size: 0.85rem; letter-spacing: 0.1em; text-transform: uppercase; background: transparent; color: var(--rose); border: 1px solid var(--rose); padding: 1rem 2.4rem; border-radius: 2px; cursor: pointer; transition: all 0.2s; }
  .btn-outline:hover { background: var(--rose); color: white; }

  /* SERVICE BLOCK */
  .service-block { padding: 6rem 4rem; max-width: 1200px; margin: 0 auto; }
  .service-block:nth-child(odd) .service-block-inner { flex-direction: row-reverse; }
  .service-block-inner { display: flex; gap: 5rem; align-items: center; }
  .service-block-visual { flex: 0 0 420px; }
  .service-block-content { flex: 1; }

  /* VISUAL CARD */
  .visual-card { background: var(--blanc); border: 1px solid var(--creme-dark); border-radius: 8px; padding: 2.4rem; box-shadow: 0 12px 40px rgba(42,31,26,0.08); position: relative; }
  .visual-card-header { display: flex; align-items: center; gap: 1rem; margin-bottom: 1.6rem; }
  .visual-card-icon { width: 44px; height: 44px; background: var(--rose-pale); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; flex-shrink: 0; }
  .visual-card-title { font-family: 'Playfair Display', serif; font-size: 1rem; font-weight: 600; color: var(--encre); }
  .visual-card-sub { font-family: 'Jost', sans-serif; font-size: 0.7rem; letter-spacing: 0.1em; text-transform: uppercase; color: var(--gris); margin-top: 0.2rem; }
  .visual-divider { height: 1px; background: var(--creme-dark); margin: 1.2rem 0; }

  /* BEFORE/AFTER */
  .before-after { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
  .ba-block { padding: 1rem; border-radius: 4px; }
  .ba-block.before { background: #fdf0f0; border: 1px solid #f0d0d0; }
  .ba-block.after { background: #f0fdf4; border: 1px solid #c6e8d0; }
  .ba-label { font-family: 'Jost', sans-serif; font-size: 0.68rem; letter-spacing: 0.15em; text-transform: uppercase; margin-bottom: 0.5rem; }
  .ba-block.before .ba-label { color: #c0706e; }
  .ba-block.after .ba-label { color: #4a9e6a; }
  .ba-text { font-size: 0.88rem; font-weight: 300; color: var(--encre-soft); line-height: 1.6; }
  .ba-text s { color: var(--gris); }
  .ba-text mark { background: rgba(201,168,76,0.2); border-radius: 2px; padding: 0 2px; }

  /* KDP PREVIEW */
  .kdp-preview { background: var(--creme); border-radius: 4px; padding: 1.2rem; font-family: 'Cormorant Garamond', serif; }
  .kdp-chapter { font-family: 'Playfair Display', serif; font-size: 1.1rem; font-weight: 600; text-align: center; margin-bottom: 0.8rem; color: var(--encre); }
  .kdp-text { font-size: 0.88rem; line-height: 1.8; color: var(--encre-soft); text-indent: 1.5em; }
  .kdp-text + .kdp-text { margin-top: 0.6rem; }
  .kdp-specs { display: flex; gap: 0.6rem; flex-wrap: wrap; margin-top: 1rem; }
  .kdp-spec { font-family: 'Jost', sans-serif; font-size: 0.68rem; letter-spacing: 0.08em; text-transform: uppercase; background: var(--rose-pale); color: var(--rose-deep); padding: 0.3rem 0.7rem; border-radius: 20px; }

  /* COVER GENERATOR */
  .cover-steps { display: flex; flex-direction: column; gap: 0.8rem; }
  .cover-step { display: flex; align-items: center; gap: 1rem; padding: 0.9rem 1rem; background: var(--creme); border-radius: 4px; border: 1px solid var(--creme-dark); transition: border-color 0.2s; }
  .cover-step.active { border-color: var(--rose-light); background: var(--rose-pale); }
  .cover-step-num { width: 28px; height: 28px; border-radius: 50%; background: var(--rose-pale); border: 1px solid var(--rose-light); display: flex; align-items: center; justify-content: center; font-family: 'Jost', sans-serif; font-size: 0.75rem; color: var(--rose-deep); flex-shrink: 0; }
  .cover-step.active .cover-step-num { background: var(--rose); color: white; border-color: var(--rose); }
  .cover-step-text { font-size: 0.9rem; font-weight: 300; color: var(--encre-soft); }
  .cover-step-value { margin-left: auto; font-family: 'Jost', sans-serif; font-size: 0.75rem; color: var(--rose); letter-spacing: 0.05em; }

  /* SERVICE CONTENT */
  .service-tag { font-family: 'Jost', sans-serif; font-size: 0.72rem; letter-spacing: 0.2em; text-transform: uppercase; color: var(--rose); margin-bottom: 0.8rem; }
  .service-title { font-family: 'Playfair Display', serif; font-size: clamp(1.7rem, 3vw, 2.3rem); font-weight: 700; line-height: 1.2; color: var(--encre); margin-bottom: 1.2rem; }
  .service-title em { font-style: italic; color: var(--rose); }
  .service-desc-text { font-size: 1.05rem; font-weight: 300; color: var(--gris); line-height: 1.75; margin-bottom: 2rem; }
  .service-features { list-style: none; display: flex; flex-direction: column; gap: 0.8rem; margin-bottom: 2.4rem; }
  .service-features li { display: flex; align-items: flex-start; gap: 0.8rem; font-size: 0.98rem; font-weight: 300; color: var(--encre-soft); }
  .service-features li::before { content: '✦'; color: var(--rose-light); font-size: 0.65rem; margin-top: 0.28rem; flex-shrink: 0; }
  .service-price-tag { display: inline-flex; align-items: center; gap: 0.6rem; background: var(--rose-pale); color: var(--rose-deep); font-family: 'Jost', sans-serif; font-size: 0.8rem; letter-spacing: 0.1em; text-transform: uppercase; padding: 0.5rem 1.1rem; border-radius: 20px; margin-bottom: 1.8rem; }
  .service-actions { display: flex; gap: 1rem; flex-wrap: wrap; }

  /* SEPARATOR */
  .service-separator { max-width: 1200px; margin: 0 auto; padding: 0 4rem; }
  .sep-line { height: 1px; background: var(--creme-dark); }

  /* FAQ MINI */
  .service-faq { background: var(--blanc); border-top: 1px solid var(--creme-dark); padding: 6rem 4rem; }
  .service-faq-inner { max-width: 800px; margin: 0 auto; }
  .faq-header { text-align: center; margin-bottom: 3rem; }
  .faq-header .section-tag { font-family: 'Jost', sans-serif; font-size: 0.75rem; letter-spacing: 0.22em; text-transform: uppercase; color: var(--rose); margin-bottom: 1rem; display: flex; align-items: center; justify-content: center; gap: 0.8rem; }
  .faq-header .section-tag::before, .faq-header .section-tag::after { content: ''; display: block; width: 30px; height: 1px; background: var(--rose-light); }
  .faq-header h2 { font-family: 'Playfair Display', serif; font-size: 2rem; font-weight: 700; color: var(--encre); }
  .faq-header h2 em { font-style: italic; color: var(--rose); }
  .faq-list { display: flex; flex-direction: column; gap: 0.8rem; }
  .faq-item { border: 1px solid var(--creme-dark); border-radius: 4px; overflow: hidden; background: var(--blanc); }
  .faq-question { width: 100%; display: flex; align-items: center; justify-content: space-between; padding: 1.3rem 1.8rem; background: none; border: none; cursor: pointer; font-family: 'Playfair Display', serif; font-size: 1.05rem; font-weight: 600; color: var(--encre); text-align: left; transition: background 0.2s; gap: 1rem; }
  .faq-question:hover { background: var(--creme); }
  .faq-arrow { color: var(--rose); font-size: 1rem; transition: transform 0.2s; flex-shrink: 0; }
  .faq-arrow.open { transform: rotate(180deg); }
  .faq-answer { padding: 0 1.8rem 1.3rem; font-size: 0.98rem; font-weight: 300; color: var(--gris); line-height: 1.7; }

  /* CTA BAND */
  .cta-band { background: linear-gradient(135deg, var(--rose-pale) 0%, var(--creme) 100%); border-top: 1px solid var(--creme-dark); padding: 5rem 4rem; text-align: center; }
  .cta-band h2 { font-family: 'Playfair Display', serif; font-size: clamp(1.8rem, 3.5vw, 2.6rem); font-weight: 700; color: var(--encre); margin-bottom: 1rem; }
  .cta-band h2 em { font-style: italic; color: var(--rose); }
  .cta-band p { font-size: 1.05rem; font-weight: 300; color: var(--gris); margin-bottom: 2rem; }
  .cta-band-btns { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; }
  .cta-fine { margin-top: 1rem; font-size: 0.85rem; color: var(--gris); font-style: italic; }

  /* FOOTER */
  footer { background: var(--encre); color: rgba(250,246,241,0.6); padding: 3rem 4rem; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1.5rem; }
  .footer-logo { font-family: 'Playfair Display', serif; font-size: 1.3rem; font-weight: 700; color: var(--creme); }
  .footer-logo span { color: var(--rose-light); font-style: italic; }
  .footer-links { display: flex; gap: 2rem; list-style: none; font-family: 'Jost', sans-serif; font-size: 0.78rem; letter-spacing: 0.1em; text-transform: uppercase; }
  .footer-links a { color: rgba(250,246,241,0.5); text-decoration: none; transition: color 0.2s; }
  .footer-links a:hover { color: var(--rose-light); }
  .footer-copy { font-family: 'Jost', sans-serif; font-size: 0.75rem; color: rgba(250,246,241,0.35); }

  @keyframes fadeUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }

  @media (max-width: 960px) {
    .nav { padding: 1rem 1.8rem; }
    .nav-links { display: none; }
    .page-hero, .service-block, .service-faq, .cta-band { padding-left: 1.8rem; padding-right: 1.8rem; }
    .service-block-inner { flex-direction: column !important; gap: 2.5rem; }
    .service-block-visual { flex: none; width: 100%; }
    .service-separator { padding: 0 1.8rem; }
    footer { padding: 2.5rem 1.8rem; flex-direction: column; text-align: center; }
    .footer-links { flex-wrap: wrap; justify-content: center; }
  }
`;

import { useState } from "react";

const faqs = [
  { q: "Quelle est la différence entre correction et embellissement ?", a: "La correction traite l'orthographe, la grammaire, la ponctuation et la syntaxe. L'embellissement va plus loin : fluidité, répétitions, tournures maladroites — toujours en respectant votre style." },
  { q: "Mes fichiers sont-ils en sécurité sur PlumePro ?", a: "Oui. Vos manuscrits sont chiffrés et ne sont jamais partagés ni utilisés pour entraîner des modèles. Vous restez propriétaire à 100% de votre texte." },
  { q: "Quels formats de fichiers acceptez-vous ?", a: "Nous acceptons les fichiers .docx, .doc, .txt et .odt. Pour la mise en page KDP, le fichier final vous est livré en .docx et .pdf prêt à importer." },
  { q: "Combien de temps faut-il pour traiter un chapitre ?", a: "La correction d'un chapitre prend en général moins de 2 minutes. La mise en page d'un roman complet est disponible en moins de 5 minutes." },
  { q: "Puis-je utiliser les couvertures générées pour une publication commerciale ?", a: "Oui, toutes les couvertures créées via PlumePro vous appartiennent et peuvent être utilisées librement pour vos publications commerciales sur KDP ou ailleurs." },
];

export default function Services({ navigate }) {
  const [openFaq, setOpenFaq] = useState(null);

  return (
    <>
      <style>{styles}</style>

      {/* NAV */}
      <nav className="nav">
        <div className="nav-logo">Plume<span>Pro</span></div>
        <ul className="nav-links">
          <li><a href="#">Accueil</a></li>
          <li><a href="#" className="active">Services</a></li>
          <li><a href="#">Tarifs</a></li>
          <li><a href="#">FAQ</a></li>
          <li><a href="#">Contact</a></li>
        </ul>
        <button className="nav-cta">Essai gratuit</button>
      </nav>

      {/* PAGE HERO */}
      <div className="page-hero">
        <p className="page-hero-tag">Nos services</p>
        <h1>Trois outils pour <em>transformer</em><br />votre manuscrit</h1>
        <p>Conçus pour les auteurs en autoédition, nos services vous accompagnent de la correction finale jusqu'à la couverture prête à publier sur KDP.</p>
      </div>

      {/* ── SERVICE 1 : CORRECTION ── */}
      <section className="service-block" id="correction">
        <div className="service-block-inner">
          <div className="service-block-visual">
            <div className="visual-card">
              <div className="visual-card-header">
                <div className="visual-card-icon">✍️</div>
                <div>
                  <div className="visual-card-title">Correction — Chapitre 7</div>
                  <div className="visual-card-sub">8 corrections · Style préservé</div>
                </div>
              </div>
              <div className="visual-divider" />
              <div className="before-after">
                <div className="ba-block before">
                  <div className="ba-label">Avant</div>
                  <p className="ba-text">Il <s>c'était</s> levé tôt ce matin là, <s>malgres</s> la fatigue qui pesait sur ses épaules.</p>
                </div>
                <div className="ba-block after">
                  <div className="ba-label">Après</div>
                  <p className="ba-text">Il s'était levé tôt ce matin-là, <mark>malgré</mark> la fatigue qui pesait sur ses épaules.</p>
                </div>
              </div>
              <div className="visual-divider" />
              <div style={{display:"flex", gap:"0.5rem", flexWrap:"wrap"}}>
                {["Orthographe","Grammaire","Typographie","Style"].map(t => (
                  <span key={t} style={{fontFamily:"'Jost',sans-serif", fontSize:"0.7rem", letterSpacing:"0.08em", textTransform:"uppercase", background:"var(--rose-pale)", color:"var(--rose-deep)", padding:"0.3rem 0.7rem", borderRadius:"20px"}}>{t}</span>
                ))}
              </div>
            </div>
          </div>
          <div className="service-block-content">
            <p className="service-tag">Service 01</p>
            <h2 className="service-title">Correction <em>intelligente</em><br />de votre roman</h2>
            <p className="service-desc-text">Notre IA, entraînée sur la langue française, corrige votre texte avec la précision d'Antidote — orthographe, grammaire, ponctuation, typographie — tout en préservant votre style et votre voix d'auteur.</p>
            <ul className="service-features">
              <li>Correction orthographique et grammaticale complète</li>
              <li>Détection des répétitions et tournures maladroites</li>
              <li>Respect des règles typographiques françaises</li>
              <li>Suggestions de style sans altérer votre voix</li>
              <li>Traitement chapitre par chapitre ou roman entier</li>
              <li>Fichier corrigé livré en .docx avec suivi des modifications</li>
            </ul>
            <div className="service-price-tag">✦ À partir de 5 crédits / chapitre</div>
            <div className="service-actions">
              <button className="btn-primary">Essayer gratuitement</button>
              <button className="btn-outline">Voir les tarifs</button>
            </div>
          </div>
        </div>
      </section>

      <div className="service-separator"><div className="sep-line" /></div>

      {/* ── SERVICE 2 : MISE EN PAGE ── */}
      <section className="service-block" id="mise-en-page">
        <div className="service-block-inner">
          <div className="service-block-visual">
            <div className="visual-card">
              <div className="visual-card-header">
                <div className="visual-card-icon">📐</div>
                <div>
                  <div className="visual-card-title">Mise en page KDP</div>
                  <div className="visual-card-sub">Format 15,24 × 22,86 cm · Prêt à publier</div>
                </div>
              </div>
              <div className="visual-divider" />
              <div className="kdp-preview">
                <div className="kdp-chapter">Chapitre I</div>
                <p className="kdp-text">La nuit tombait sur la ville endormie. Elena remonta son col, les yeux rivés sur la façade grise de l'immeuble.</p>
                <p className="kdp-text">Elle hésita un instant, puis poussa la porte.</p>
              </div>
              <div className="kdp-specs">
                {["Marges KDP","Police Garamond","Interligne 1.5","En-têtes","Numérotation","Export PDF"].map(s => (
                  <span key={s} className="kdp-spec">{s}</span>
                ))}
              </div>
            </div>
          </div>
          <div className="service-block-content">
            <p className="service-tag">Service 02</p>
            <h2 className="service-title">Mise en page <em>aux normes</em><br />Amazon KDP</h2>
            <p className="service-desc-text">Importez votre manuscrit Word, nous nous occupons du reste. Marges calibrées, typographie soignée, en-têtes et numérotation automatiques — votre roman ressortira exactement comme un livre de librairie.</p>
            <ul className="service-features">
              <li>Formats optimisés pour tous les gabarits KDP</li>
              <li>Typographie professionnelle (Garamond, Times...)</li>
              <li>Marges intérieures/extérieures selon les normes d'impression</li>
              <li>En-têtes avec titre et nom d'auteur</li>
              <li>Numérotation des pages automatique</li>
              <li>Livraison en .docx et .pdf prêt à importer sur KDP</li>
            </ul>
            <div className="service-price-tag">✦ 49 crédits / roman complet</div>
            <div className="service-actions">
              <button className="btn-primary">Mettre en page mon roman</button>
              <button className="btn-outline">Voir les tarifs</button>
            </div>
          </div>
        </div>
      </section>

      <div className="service-separator"><div className="sep-line" /></div>

      {/* ── SERVICE 3 : COUVERTURE ── */}
      <section className="service-block" id="couverture">
        <div className="service-block-inner">
          <div className="service-block-visual">
            <div className="visual-card">
              <div className="visual-card-header">
                <div className="visual-card-icon">🎨</div>
                <div>
                  <div className="visual-card-title">Générateur de couverture</div>
                  <div className="visual-card-sub">Personnalisation libre · Export KDP</div>
                </div>
              </div>
              <div className="visual-divider" />
              <div className="cover-steps">
                {[
                  { num:1, text:"Choisissez votre genre", value:"Romance 💕", active:false },
                  { num:2, text:"Définissez l'ambiance", value:"Doux & lumineux", active:false },
                  { num:3, text:"Sélectionnez vos couleurs", value:"Rose & crème", active:true },
                  { num:4, text:"L'IA génère 3 propositions", value:"En cours…", active:false },
                  { num:5, text:"Personnalisez & exportez", value:"Format KDP", active:false },
                ].map(s => (
                  <div key={s.num} className={`cover-step${s.active ? " active" : ""}`}>
                    <div className="cover-step-num">{s.num}</div>
                    <span className="cover-step-text">{s.text}</span>
                    <span className="cover-step-value">{s.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="service-block-content">
            <p className="service-tag">Service 03</p>
            <h2 className="service-title">Créez votre couverture<br /><em>en quelques clics</em></h2>
            <p className="service-desc-text">Plus besoin de payer un graphiste 300 € ou de passer des heures sur Canva. Notre générateur guidé crée des propositions de couvertures professionnelles que vous pouvez personnaliser librement — titre, police, couleurs, éléments visuels.</p>
            <ul className="service-features">
              <li>Générateur guidé étape par étape</li>
              <li>3 propositions IA basées sur votre genre et ambiance</li>
              <li>Personnalisation libre (texte, couleurs, éléments)</li>
              <li>Dimensions exactes aux normes KDP (broché + ebook)</li>
              <li>Export haute résolution prêt à importer</li>
              <li>Droits commerciaux complets inclus</li>
            </ul>
            <div className="service-price-tag">✦ 29 crédits / couverture</div>
            <div className="service-actions">
              <button className="btn-primary">Créer ma couverture</button>
              <button className="btn-outline">Voir les tarifs</button>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <div className="service-faq">
        <div className="service-faq-inner">
          <div className="faq-header">
            <p className="section-tag">Questions fréquentes</p>
            <h2>Vous avez des <em>questions</em> ?</h2>
          </div>
          <div className="faq-list">
            {faqs.map((f, i) => (
              <div className="faq-item" key={i}>
                <button className="faq-question" onClick={() => setOpenFaq(openFaq === i ? null : i)}>
                  {f.q}
                  <span className={`faq-arrow${openFaq === i ? " open" : ""}`}>▼</span>
                </button>
                {openFaq === i && <div className="faq-answer">{f.a}</div>}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="cta-band">
        <h2>Prêt à publier votre roman<br /><em>avec confiance ?</em></h2>
        <p>Commencez avec 3 corrections gratuites — sans carte bancaire, sans engagement.</p>
        <div className="cta-band-btns">
          <button className="btn-primary">Commencer gratuitement</button>
        </div>
        <p className="cta-fine">✦ 3 corrections offertes · Sans carte bancaire · Sans engagement</p>
      </div>

      {/* FOOTER */}
      <footer>
        <div className="footer-logo">Plume<span>Pro</span></div>
        <ul className="footer-links">
          {["Accueil","Services","Tarifs","FAQ","Contact","Mentions légales"].map(l => <li key={l}><a href="#">{l}</a></li>)}
        </ul>
        <span className="footer-copy">© 2026 PlumePro · Tous droits réservés</span>
      </footer>
    </>
  );
}
