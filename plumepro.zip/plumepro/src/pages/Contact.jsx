import Nav from '../components/Nav';
import Footer from '../components/Footer';

import { useState } from "react";

const styles = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400;1,600&family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;1,300;1,400&family=Jost:wght@300;400;500&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --creme: #faf6f1; --creme-dark: #f0e9e0;
    --rose: #d4899a; --rose-light: #e8b4bf; --rose-pale: #f5dde3; --rose-deep: #b8637a;
    --or: #c9a84c; --or-light: #e2c47a;
    --encre: #2a1f1a; --encre-soft: #4a3830; --gris: #8a7e78; --blanc: #fdfaf6;
  }
  html { scroll-behavior: smooth; }
  body { font-family: 'Cormorant Garamond', Georgia, serif; background: var(--creme); color: var(--encre); overflow-x: hidden; }

  /* NAV */
  .nav { position: fixed; top: 0; left: 0; right: 0; z-index: 100; display: flex; align-items: center; justify-content: space-between; padding: 1.2rem 4rem; background: rgba(250,246,241,0.93); backdrop-filter: blur(14px); border-bottom: 1px solid rgba(212,137,154,0.2); }
  .nav-logo { font-family: 'Playfair Display', serif; font-size: 1.5rem; font-weight: 700; color: var(--encre); cursor: pointer; }
  .nav-logo span { color: var(--rose); font-style: italic; }
  .nav-links { display: flex; gap: 2.5rem; list-style: none; font-family: 'Jost', sans-serif; font-size: 0.82rem; letter-spacing: 0.12em; text-transform: uppercase; }
  .nav-links a { color: var(--encre-soft); text-decoration: none; transition: color 0.2s; }
  .nav-links a:hover, .nav-links a.active { color: var(--rose); }
  .nav-cta { font-family: 'Jost', sans-serif; font-size: 0.82rem; letter-spacing: 0.1em; text-transform: uppercase; background: var(--rose); color: white; border: none; padding: 0.65rem 1.6rem; border-radius: 2px; cursor: pointer; transition: background 0.2s; }
  .nav-cta:hover { background: var(--rose-deep); }

  /* PAGE HERO */
  .page-hero { padding: 10rem 4rem 5rem; text-align: center; position: relative; overflow: hidden; }
  .page-hero::before { content: ''; position: absolute; width: 500px; height: 500px; border-radius: 50%; background: radial-gradient(circle, rgba(245,221,227,0.45) 0%, transparent 70%); top: -100px; right: -100px; pointer-events: none; }
  .page-hero-tag { font-family: 'Jost', sans-serif; font-size: 0.75rem; letter-spacing: 0.22em; text-transform: uppercase; color: var(--rose); margin-bottom: 1rem; display: flex; align-items: center; justify-content: center; gap: 0.8rem; }
  .page-hero-tag::before, .page-hero-tag::after { content: ''; display: block; width: 30px; height: 1px; background: var(--rose-light); }
  .page-hero h1 { font-family: 'Playfair Display', serif; font-size: clamp(2.4rem, 5vw, 4rem); font-weight: 700; line-height: 1.15; color: var(--encre); margin-bottom: 1.2rem; }
  .page-hero h1 em { font-style: italic; color: var(--rose); }
  .page-hero p { font-size: 1.2rem; font-weight: 300; color: var(--gris); max-width: 520px; margin: 0 auto; line-height: 1.7; }

  /* MAIN */
  .contact-main { padding: 5rem 4rem 7rem; max-width: 1100px; margin: 0 auto; display: grid; grid-template-columns: 1fr 1.6fr; gap: 5rem; align-items: start; }

  /* LEFT INFO */
  .contact-info { display: flex; flex-direction: column; gap: 2.5rem; }
  .info-block { display: flex; gap: 1.2rem; align-items: flex-start; }
  .info-icon { width: 44px; height: 44px; background: var(--rose-pale); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; flex-shrink: 0; margin-top: 0.1rem; }
  .info-title { font-family: 'Playfair Display', serif; font-size: 1.05rem; font-weight: 600; color: var(--encre); margin-bottom: 0.3rem; }
  .info-text { font-size: 0.95rem; font-weight: 300; color: var(--gris); line-height: 1.65; }
  .info-text a { color: var(--rose); text-decoration: none; }
  .info-text a:hover { text-decoration: underline; }

  .info-divider { height: 1px; background: var(--creme-dark); }

  .response-box { background: var(--blanc); border: 1px solid var(--creme-dark); border-radius: 6px; padding: 1.8rem; }
  .response-title { font-family: 'Playfair Display', serif; font-size: 1rem; font-weight: 600; color: var(--encre); margin-bottom: 1rem; }
  .response-items { display: flex; flex-direction: column; gap: 0.7rem; }
  .response-item { display: flex; align-items: center; gap: 0.8rem; font-size: 0.9rem; font-weight: 300; color: var(--encre-soft); }
  .response-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--rose-light); flex-shrink: 0; }
  .response-dot.green { background: #4a9e6a; }

  /* FORM */
  .contact-form-wrap { background: var(--blanc); border: 1px solid var(--creme-dark); border-radius: 8px; padding: 3rem; box-shadow: 0 8px 32px rgba(42,31,26,0.06); }
  .form-title { font-family: 'Playfair Display', serif; font-size: 1.5rem; font-weight: 700; color: var(--encre); margin-bottom: 0.4rem; }
  .form-title em { font-style: italic; color: var(--rose); }
  .form-sub { font-size: 0.95rem; font-weight: 300; color: var(--gris); margin-bottom: 2.2rem; line-height: 1.6; }

  .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1.2rem; }
  .form-group { display: flex; flex-direction: column; gap: 0.5rem; margin-bottom: 1.4rem; }
  .form-label { font-family: 'Jost', sans-serif; font-size: 0.72rem; letter-spacing: 0.15em; text-transform: uppercase; color: var(--encre-soft); }
  .form-input, .form-select, .form-textarea { font-family: 'Cormorant Garamond', serif; font-size: 1rem; font-weight: 300; color: var(--encre); background: var(--creme); border: 1px solid var(--creme-dark); border-radius: 3px; padding: 0.85rem 1.1rem; outline: none; transition: border-color 0.2s, box-shadow 0.2s; width: 100%; }
  .form-input:focus, .form-select:focus, .form-textarea:focus { border-color: var(--rose-light); box-shadow: 0 0 0 3px rgba(212,137,154,0.12); background: var(--blanc); }
  .form-input::placeholder, .form-textarea::placeholder { color: var(--gris); }
  .form-textarea { resize: vertical; min-height: 140px; }
  .form-select { appearance: none; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%238a7e78' stroke-width='1.5' fill='none' stroke-linecap='round'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right 1rem center; cursor: pointer; }

  .form-check { display: flex; align-items: flex-start; gap: 0.8rem; margin-bottom: 1.8rem; cursor: pointer; }
  .form-check input[type="checkbox"] { width: 16px; height: 16px; margin-top: 0.2rem; accent-color: var(--rose); flex-shrink: 0; cursor: pointer; }
  .form-check-label { font-size: 0.88rem; font-weight: 300; color: var(--gris); line-height: 1.5; }

  .btn-submit { width: 100%; font-family: 'Jost', sans-serif; font-size: 0.85rem; letter-spacing: 0.12em; text-transform: uppercase; background: var(--rose); color: white; border: none; padding: 1.1rem; border-radius: 2px; cursor: pointer; transition: background 0.2s, transform 0.15s, box-shadow 0.2s; box-shadow: 0 4px 20px rgba(212,137,154,0.35); }
  .btn-submit:hover { background: var(--rose-deep); transform: translateY(-2px); }
  .btn-submit:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }

  /* SUCCESS */
  .success-box { text-align: center; padding: 3rem 2rem; }
  .success-icon { font-size: 3rem; margin-bottom: 1.2rem; }
  .success-title { font-family: 'Playfair Display', serif; font-size: 1.6rem; font-weight: 700; color: var(--encre); margin-bottom: 0.8rem; }
  .success-title em { font-style: italic; color: var(--rose); }
  .success-text { font-size: 1rem; font-weight: 300; color: var(--gris); line-height: 1.7; max-width: 360px; margin: 0 auto 1.8rem; }
  .btn-reset { font-family: 'Jost', sans-serif; font-size: 0.8rem; letter-spacing: 0.1em; text-transform: uppercase; background: transparent; color: var(--encre-soft); border: 1px solid var(--creme-dark); padding: 0.7rem 1.6rem; border-radius: 2px; cursor: pointer; transition: all 0.2s; }
  .btn-reset:hover { border-color: var(--rose); color: var(--rose); }

  /* CTA */
  .cta-band { background: linear-gradient(135deg, var(--rose-pale) 0%, var(--creme) 100%); border-top: 1px solid var(--creme-dark); padding: 5rem 4rem; text-align: center; }
  .cta-band h2 { font-family: 'Playfair Display', serif; font-size: clamp(1.8rem, 3.5vw, 2.6rem); font-weight: 700; color: var(--encre); margin-bottom: 1rem; }
  .cta-band h2 em { font-style: italic; color: var(--rose); }
  .cta-band p { font-size: 1.05rem; font-weight: 300; color: var(--gris); margin-bottom: 2rem; }
  .btn-primary { font-family: 'Jost', sans-serif; font-size: 0.85rem; letter-spacing: 0.1em; text-transform: uppercase; background: var(--rose); color: white; border: none; padding: 1rem 2.4rem; border-radius: 2px; cursor: pointer; transition: background 0.2s, transform 0.15s; box-shadow: 0 4px 20px rgba(212,137,154,0.35); }
  .btn-primary:hover { background: var(--rose-deep); transform: translateY(-2px); }
  .cta-fine { margin-top: 1rem; font-size: 0.85rem; color: var(--gris); font-style: italic; }

  /* FOOTER */
  footer { background: var(--encre); color: rgba(250,246,241,0.6); padding: 3rem 4rem; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1.5rem; }
  .footer-logo { font-family: 'Playfair Display', serif; font-size: 1.3rem; font-weight: 700; color: var(--creme); }
  .footer-logo span { color: var(--rose-light); font-style: italic; }
  .footer-links { display: flex; gap: 2rem; list-style: none; font-family: 'Jost', sans-serif; font-size: 0.78rem; letter-spacing: 0.1em; text-transform: uppercase; }
  .footer-links a { color: rgba(250,246,241,0.5); text-decoration: none; transition: color 0.2s; }
  .footer-links a:hover { color: var(--rose-light); }
  .footer-copy { font-family: 'Jost', sans-serif; font-size: 0.75rem; color: rgba(250,246,241,0.35); }

  @media (max-width: 960px) {
    .nav { padding: 1rem 1.8rem; }
    .nav-links { display: none; }
    .page-hero, .cta-band { padding-left: 1.8rem; padding-right: 1.8rem; }
    .contact-main { grid-template-columns: 1fr; padding: 3rem 1.8rem 5rem; gap: 3rem; }
    .form-row { grid-template-columns: 1fr; }
    .contact-form-wrap { padding: 2rem 1.6rem; }
    footer { padding: 2.5rem 1.8rem; flex-direction: column; text-align: center; }
    .footer-links { flex-wrap: wrap; justify-content: center; }
  }
`;

export default function Contact({ navigate }) {
  const [form, setForm] = useState({ prenom: "", nom: "", email: "", sujet: "", message: "", newsletter: false });
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  const handle = e => {
    const { name, value, type, checked } = e.target;
    setForm(f => ({ ...f, [name]: type === "checkbox" ? checked : value }));
  };

  const submit = e => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => { setLoading(false); setSent(true); }, 1200);
  };

  return (
    <>
      <style>{styles}</style>

      {/* NAV */}
      <nav className="nav">
        <div className="nav-logo">Plume<span>Pro</span></div>
        <ul className="nav-links">
          <li><a href="#">Accueil</a></li>
          <li><a href="#">Services</a></li>
          <li><a href="#">Tarifs</a></li>
          <li><a href="#">FAQ</a></li>
          <li><a href="#" className="active">Contact</a></li>
        </ul>
        <button className="nav-cta">Essai gratuit</button>
      </nav>

      {/* HERO */}
      <div className="page-hero">
        <p className="page-hero-tag">Contact</p>
        <h1>On est là pour<br /><em>vous aider</em></h1>
        <p>Une question, une suggestion, un problème technique ? Écrivez-nous, nous vous répondons rapidement.</p>
      </div>

      {/* MAIN */}
      <div className="contact-main">

        {/* INFOS */}
        <div className="contact-info">
          <div className="info-block">
            <div className="info-icon">✉️</div>
            <div>
              <p className="info-title">Email</p>
              <p className="info-text"><a href="mailto:contact@plumepro.fr">contact@plumepro.fr</a></p>
            </div>
          </div>
          <div className="info-block">
            <div className="info-icon">💬</div>
            <div>
              <p className="info-title">Chat en direct</p>
              <p className="info-text">Disponible depuis votre espace personnel une fois connecté.</p>
            </div>
          </div>
          <div className="info-block">
            <div className="info-icon">📚</div>
            <div>
              <p className="info-title">Centre d'aide</p>
              <p className="info-text">Consultez notre <a href="#">FAQ complète</a> pour trouver une réponse immédiate.</p>
            </div>
          </div>

          <div className="info-divider" />

          <div className="response-box">
            <p className="response-title">⏱ Délais de réponse</p>
            <div className="response-items">
              <div className="response-item"><div className="response-dot green" />Questions générales — sous 24h</div>
              <div className="response-item"><div className="response-dot green" />Problème technique — sous 4h</div>
              <div className="response-item"><div className="response-dot" />Abonnés Auteur — support prioritaire</div>
            </div>
          </div>
        </div>

        {/* FORMULAIRE */}
        <div className="contact-form-wrap">
          {sent ? (
            <div className="success-box">
              <div className="success-icon">🌸</div>
              <h2 className="success-title">Message <em>envoyé !</em></h2>
              <p className="success-text">Merci pour votre message. Nous vous répondrons dans les plus brefs délais, généralement sous 24 heures.</p>
              <button className="btn-reset" onClick={() => { setSent(false); setForm({ prenom:"", nom:"", email:"", sujet:"", message:"", newsletter:false }); }}>
                Envoyer un autre message
              </button>
            </div>
          ) : (
            <>
              <h2 className="form-title">Envoyez-nous un <em>message</em></h2>
              <p className="form-sub">Tous les champs marqués d'un * sont obligatoires.</p>
              <form onSubmit={submit}>
                <div className="form-row">
                  <div className="form-group">
                    <label className="form-label">Prénom *</label>
                    <input className="form-input" type="text" name="prenom" placeholder="Sophie" value={form.prenom} onChange={handle} required />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Nom *</label>
                    <input className="form-input" type="text" name="nom" placeholder="Martin" value={form.nom} onChange={handle} required />
                  </div>
                </div>
                <div className="form-group">
                  <label className="form-label">Email *</label>
                  <input className="form-input" type="email" name="email" placeholder="sophie@exemple.fr" value={form.email} onChange={handle} required />
                </div>
                <div className="form-group">
                  <label className="form-label">Sujet *</label>
                  <select className="form-select" name="sujet" value={form.sujet} onChange={handle} required>
                    <option value="">Choisissez un sujet…</option>
                    <option value="question-service">Question sur un service</option>
                    <option value="probleme-technique">Problème technique</option>
                    <option value="question-tarif">Question sur les tarifs</option>
                    <option value="question-kdp">Question sur KDP</option>
                    <option value="partenariat">Partenariat</option>
                    <option value="autre">Autre</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Message *</label>
                  <textarea className="form-textarea" name="message" placeholder="Décrivez votre question ou votre problème en détail…" value={form.message} onChange={handle} required />
                </div>
                <label className="form-check">
                  <input type="checkbox" name="newsletter" checked={form.newsletter} onChange={handle} />
                  <span className="form-check-label">J'accepte de recevoir les actualités et conseils de PlumePro (optionnel, résiliable à tout moment).</span>
                </label>
                <button className="btn-submit" type="submit" disabled={loading}>
                  {loading ? "Envoi en cours…" : "Envoyer le message ✦"}
                </button>
              </form>
            </>
          )}
        </div>
      </div>

      {/* CTA */}
      <div className="cta-band">
        <h2>Pas encore inscrit ?<br /><em>Essayez gratuitement !</em></h2>
        <p>3 corrections offertes, sans carte bancaire. Publiez votre roman avec confiance.</p>
        <button className="btn-primary">Commencer gratuitement</button>
        <p className="cta-fine">✦ Sans carte bancaire · Sans engagement · Résiliable à tout moment</p>
      </div>

      {/* FOOTER */}
      <footer>
        <div className="footer-logo">Plume<span>Pro</span></div>
        <ul className="footer-links">
          {["Accueil","Services","Tarifs","FAQ","Contact","Mentions légales"].map(l => <li key={l}><a href="#">{l}</a></li>)}
        </ul>
        <span className="footer-copy">© 2026 PlumePro · Tous droits réservés</span>
      </footer>
    </>
  );
}
